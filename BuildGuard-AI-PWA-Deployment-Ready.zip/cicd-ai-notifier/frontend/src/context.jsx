import { createContext, useContext, useEffect, useState } from "react";
import { api, getToken } from "./api";

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function Providers({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());
  const [status, setStatus] = useState(null);
  const [dark, setDark] = useState(localStorage.getItem("theme") !== "light");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);
  useEffect(() => { api.get("/system/status").then(setStatus).catch(() => {}); }, []);
  useEffect(() => {
    if (!getToken()) return;
    api.get("/auth/me").then(setUser).catch(() => localStorage.removeItem("token")).finally(() => setLoading(false));
  }, []);

  const authenticate = async (mode, body) => {
    const r = await api.post(`/auth/${mode}`, body);
    localStorage.setItem("token", r.token);
    setUser(r.user);
  };
  const logout = () => { localStorage.removeItem("token"); setUser(null); window.location.href = "/"; };
  return <Ctx.Provider value={{ user, loading, status, dark, setDark, authenticate, logout }}>{children}</Ctx.Provider>;
}
