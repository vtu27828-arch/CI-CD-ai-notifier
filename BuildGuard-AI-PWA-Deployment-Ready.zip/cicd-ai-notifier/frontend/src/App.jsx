import { Navigate, Route, Routes } from "react-router-dom";
import { useApp } from "./context";
import Layout from "./components/Layout";
import { Spinner } from "./components/ui";
import Landing from "./pages/Landing";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Projects from "./pages/Projects";
import Builds from "./pages/Builds";
import LogAnalysis from "./pages/LogAnalysis";
import Suggestions from "./pages/Suggestions";
import Chat from "./pages/Chat";
import Notifications from "./pages/Notifications";
import Admin from "./pages/Admin";
import SettingsPage from "./pages/Settings";

function Protected({ children, admin }) {
  const { user, loading } = useApp();
  if (loading) return <Spinner full />;
  if (!user) return <Navigate to="/login" replace />;
  if (admin && user.role !== "admin") return <Navigate to="/dashboard" replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Auth mode="login" />} />
      <Route path="/register" element={<Auth mode="register" />} />
      <Route element={<Protected><Layout /></Protected>}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/builds" element={<Builds />} />
        <Route path="/logs" element={<LogAnalysis />} />
        <Route path="/logs/:id" element={<LogAnalysis />} />
        <Route path="/suggestions" element={<Suggestions />} />
        <Route path="/suggestions/:id" element={<Suggestions />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/admin" element={<Protected admin><Admin /></Protected>} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
