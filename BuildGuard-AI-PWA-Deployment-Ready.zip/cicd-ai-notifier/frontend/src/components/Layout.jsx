import { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { Bell, FileSearch, FolderGit2, History, LayoutDashboard, LogOut, Menu, MessageSquare, Moon, Settings, Shield, Sparkles, Sun, Workflow } from "lucide-react";
import { useApp } from "../context";

const NAV = [
  ["/dashboard", "Dashboard", LayoutDashboard], ["/projects", "Projects & Jenkins", FolderGit2], ["/builds", "Build History", History],
  ["/logs", "Log Analysis", FileSearch], ["/suggestions", "AI Code Suggestions", Sparkles], ["/chat", "AI Assistant", MessageSquare],
  ["/notifications", "Notifications", Bell], ["/settings", "Settings", Settings],
];

export default function Layout() {
  const { user, logout, dark, setDark, status } = useApp();
  const [open, setOpen] = useState(false);
  const items = user.role === "admin" ? [...NAV.slice(0, 7), ["/admin", "Admin Panel", Shield], NAV[7]] : NAV;
  return (
    <div className="flex min-h-screen">
      <aside className={`fixed inset-y-0 z-30 w-64 border-r border-slate-200 bg-white p-4 transition-transform dark:border-slate-800 dark:bg-slate-900 lg:static lg:translate-x-0 ${open ? "" : "-translate-x-full"}`}>
        <div className="mb-6 flex items-center gap-2 px-2 text-lg font-bold"><Workflow className="text-indigo-500" /> BuildGuard AI</div>
        <nav className="space-y-1">{items.map(([to, label, Icon]) => (
          <NavLink key={to} to={to} onClick={() => setOpen(false)} className={({ isActive }) =>
            `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition ${isActive ? "bg-indigo-600 text-white" : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"}`}>
            <Icon size={18} />{label}</NavLink>))}</nav>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur dark:border-slate-800 dark:bg-slate-900/80">
          <button className="lg:hidden" onClick={() => setOpen(!open)}><Menu /></button>
          <div className="hidden text-sm text-slate-500 lg:block">Jenkins failure monitoring with Claude AI</div>
          <div className="flex items-center gap-3">
            <button className="btn-ghost !p-2" onClick={() => setDark(!dark)} title="Toggle theme">{dark ? <Sun size={16} /> : <Moon size={16} />}</button>
            <span className="hidden text-sm sm:block">{user.name} <span className="badge bg-indigo-500/15 text-indigo-500">{user.role}</span></span>
            <button className="btn-ghost !p-2" onClick={logout} title="Logout"><LogOut size={16} /></button>
          </div>
        </header>
        {status?.demo_mode && <div className="bg-amber-500/15 px-4 py-1.5 text-center text-xs text-amber-600 dark:text-amber-400">
          DEMO MODE - sample data, simulated notifications{status.ai_live ? "" : ", rule-based AI (add ANTHROPIC_API_KEY for live Claude)"}</div>}
        <main className="mx-auto w-full max-w-7xl flex-1 p-4 sm:p-6"><Outlet /></main>
      </div>
    </div>
  );
}
