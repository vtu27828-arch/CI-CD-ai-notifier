import { useState } from "react";
import Editor from "react-simple-code-editor";
import Prism from "prismjs";
import "prismjs/components/prism-python";
import "prismjs/components/prism-yaml";
import "prismjs/components/prism-bash";
import "prismjs/components/prism-json";
import "prismjs/components/prism-typescript";
import "prismjs/components/prism-docker";
import "prismjs/components/prism-groovy";
import { Check, Copy, Loader2 } from "lucide-react";

export const STAGES = { dependency_installation: "Dependency Install", compilation: "Compilation", testing: "Testing",
  deployment: "Deployment", build: "Build", configuration: "Configuration" };
export const fmt = (d) => (d ? new Date(d).toLocaleString() : "-");
export const copyText = (t) => navigator.clipboard?.writeText(t);
export function download(name, text) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  a.download = name; a.click(); URL.revokeObjectURL(a.href);
}

export const Spinner = ({ full }) => (
  <div className={`flex items-center justify-center ${full ? "h-screen" : "p-10"}`}><Loader2 className="h-6 w-6 animate-spin text-indigo-500" /></div>
);
export const Card = ({ children, className = "", ...p }) => <div className={`card animate-fade ${className}`} {...p}>{children}</div>;

const COLORS = { success: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", failed: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  running: "bg-sky-500/15 text-sky-600 dark:text-sky-400", cancelled: "bg-slate-500/15 text-slate-500", sent: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  simulated: "bg-amber-500/15 text-amber-600 dark:text-amber-400", skipped: "bg-slate-500/15 text-slate-500", none: "bg-slate-500/15 text-slate-500" };
export const StatusBadge = ({ s }) => <span className={`badge ${COLORS[s] || COLORS.none}`}>{s}</span>;
export const Badge = ({ children, color = "bg-indigo-500/15 text-indigo-600 dark:text-indigo-300" }) => <span className={`badge ${color}`}>{children}</span>;

export const PageHeader = ({ title, sub, children }) => (
  <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
    <div><h1 className="text-2xl font-bold">{title}</h1>{sub && <p className="mt-1 text-sm text-slate-500">{sub}</p>}</div>
    <div className="flex flex-wrap items-center gap-2">{children}</div>
  </div>
);
export const Empty = ({ text }) => <p className="p-8 text-center text-sm text-slate-500">{text}</p>;
export const ErrorMsg = ({ msg }) => msg ? <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-sm text-rose-500">{msg}</p> : null;

const LANG = { py: "python", python: "python", yaml: "yaml", yml: "yaml", bash: "bash", sh: "bash", shell: "bash", json: "json",
  typescript: "typescript", ts: "typescript", dockerfile: "docker", docker: "docker", groovy: "groovy", javascript: "javascript", js: "javascript" };
const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;");
export function highlight(code, lang) {
  const l = LANG[(lang || "").toLowerCase()];
  return l && Prism.languages[l] ? Prism.highlight(code, Prism.languages[l], l) : esc(code);
}

/** Editable code editor with syntax highlighting (review before applying - nothing is auto-applied). */
export const CodeEditor = ({ value, onChange, language, readOnly }) => (
  <div className="max-h-[420px] overflow-auto rounded-xl border border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-950">
    <Editor value={value} onValueChange={onChange || (() => {})} readOnly={readOnly} highlight={(c) => highlight(c, language)} padding={14}
      style={{ fontFamily: "ui-monospace, Consolas, monospace", fontSize: 13, minHeight: 120 }} />
  </div>
);

export function CopyBtn({ text }) {
  const [ok, setOk] = useState(false);
  return <button className="btn-ghost !px-2 !py-1 text-xs" onClick={() => { copyText(text); setOk(true); setTimeout(() => setOk(false), 1500); }}>
    {ok ? <Check size={14} /> : <Copy size={14} />}{ok ? "Copied" : "Copy"}</button>;
}

/** Renders text with ```fenced``` code blocks and **bold** (used by the chatbot). */
export function RichText({ text }) {
  return <div className="space-y-2 text-sm">{text.split(/```/).map((part, i) => {
    if (i % 2 === 0) return part.trim() ? <p key={i} className="whitespace-pre-wrap" dangerouslySetInnerHTML={{
      __html: esc(part).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/_\((.+?)\)_/g, "<i class='text-slate-500'>($1)</i>") }} /> : null;
    const nl = part.indexOf("\n"); const lang = part.slice(0, nl).trim(); const code = part.slice(nl + 1).replace(/\n$/, "");
    return <div key={i} className="overflow-hidden rounded-lg border border-slate-200 dark:border-slate-700">
      <div className="flex items-center justify-between bg-slate-100 px-3 py-1 text-xs dark:bg-slate-800"><span>{lang || "code"}</span><CopyBtn text={code} /></div>
      <pre className="overflow-auto bg-slate-50 p-3 text-xs dark:bg-slate-950"><code dangerouslySetInnerHTML={{ __html: highlight(code, lang) }} /></pre></div>;
  })}</div>;
}
