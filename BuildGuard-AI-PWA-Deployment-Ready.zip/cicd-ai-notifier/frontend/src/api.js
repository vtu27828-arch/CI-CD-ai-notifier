const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "").replace(/\/$/, "");
export const getToken = () => localStorage.getItem("token");

async function req(path, { method = "GET", body, form } = {}) {
  const headers = {};
  const t = getToken();
  if (t) headers.Authorization = `Bearer ${t}`;
  let payload;
  if (form) payload = form;
  else if (body !== undefined) { headers["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
  const r = await fetch(API_BASE_URL + "/api" + path, { method, headers, body: payload });
  if (r.status === 401 && !path.startsWith("/auth/")) { localStorage.removeItem("token"); window.location.href = "/login"; }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    const d = data.detail;
    throw new Error(typeof d === "string" ? d : d?.[0]?.msg || "Request failed");
  }
  return data;
}
export const api = {
  get: (p) => req(p),
  post: (p, body) => req(p, { method: "POST", body: body ?? {} }),
  put: (p, body) => req(p, { method: "PUT", body }),
  patch: (p, body) => req(p, { method: "PATCH", body }),
  del: (p) => req(p, { method: "DELETE" }),
  upload: (p, form) => req(p, { method: "POST", form }),
};

import { useCallback, useEffect, useState } from "react";
/** useLoad(() => api.get(..), [deps]) -> {data, loading, error, reload} */
export function useLoad(fn, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: "" });
  const run = useCallback(() => {
    setState((s) => ({ ...s, loading: true }));
    return fn().then((data) => setState({ data, loading: false, error: "" }))
      .catch((e) => setState({ data: null, loading: false, error: e.message }));
  }, deps); // eslint-disable-line
  useEffect(() => { run(); }, [run]);
  return { ...state, reload: run };
}
