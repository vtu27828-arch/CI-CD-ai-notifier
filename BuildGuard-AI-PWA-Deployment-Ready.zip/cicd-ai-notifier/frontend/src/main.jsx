import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { Providers } from "./context.jsx";
import "./index.css";
createRoot(document.getElementById("root")).render(
  <BrowserRouter><Providers><App /></Providers></BrowserRouter>
);

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((error) => console.error('App offline support could not be enabled:', error));
  });
}
