import { useState } from "react";
import { Link } from "react-router-dom";
import { Mail, MessageSquare, Send, Users } from "lucide-react";
import { api, useLoad } from "../api";
import { Card, Empty, PageHeader, Spinner, StatusBadge, fmt } from "../components/ui";

const ICON = { email: Mail, slack: MessageSquare, teams: Users };
export default function Notifications() {
  const { data, loading, reload } = useLoad(() => api.get("/notifications"));
  const [msg, setMsg] = useState("");
  const resend = async (id) => { const r = await api.post(`/notifications/test/${id}`); setMsg(r.results.map((x) => `${x.channel}: ${x.status}`).join(" | ")); reload(); };
  return (
    <>
      <PageHeader title="Notification History" sub="Email, Slack and Microsoft Teams alerts sent on build failure" />
      {msg && <p className="mb-3 rounded-lg bg-indigo-500/10 p-2 text-sm text-indigo-500">Resend result - {msg}</p>}
      <Card className="overflow-x-auto !p-0">{loading ? <Spinner /> : !data.length ? <Empty text="No notifications yet" /> : (
        <table className="w-full"><thead><tr className="border-b border-slate-200 dark:border-slate-800">{["Time", "Build", "Project", "Channel", "Status", "Detail", ""].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
          <tbody>{data.map((n) => { const I = ICON[n.channel]; return (
            <tr key={n.id} className="border-b border-slate-100 dark:border-slate-800/60">
              <td className="td text-xs text-slate-500">{fmt(n.created_at)}</td><td className="td"><Link className="text-indigo-500" to={`/logs/${n.build_id}`}>#{n.build_id}</Link></td>
              <td className="td">{n.project}</td><td className="td"><span className="inline-flex items-center gap-1 capitalize"><I size={14} />{n.channel}</span></td>
              <td className="td"><StatusBadge s={n.status} /></td><td className="td max-w-xs truncate text-xs text-slate-500" title={n.detail}>{n.detail}</td>
              <td className="td"><button className="btn-ghost !py-1 text-xs" onClick={() => resend(n.build_id)}><Send size={12} />Resend</button></td></tr>); })}</tbody></table>)}</Card>
    </>
  );
}
