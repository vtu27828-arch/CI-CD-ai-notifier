import { Link } from "react-router-dom";
import { Bell, Bot, Eye, FileSearch, History, Moon, Radar, Sparkles, Sun, Workflow } from "lucide-react";
import { useApp } from "../context";

const FEATURES = [
  [Radar, "Detect", "Jenkins posts every failed build to the backend; the failed stage is identified automatically."],
  [FileSearch, "Analyze", "Console logs are parsed for error lines, categories and timestamps with highlighting."],
  [Bot, "AI Debugging", "Claude explains the root cause and generates fixed code, dependencies and Jenkinsfiles."],
  [Bell, "Notify", "Detailed alerts via Email, Slack and Microsoft Teams - with the AI solution included."],
  [History, "Track", "Every build and failure is stored for search, filtering and trend charts."],
  [Eye, "Human in control", "AI code is only suggested. Nothing is ever applied or executed without your approval."],
];

export default function Landing() {
  const { user, dark, setDark } = useApp();
  return (
    <div className="hero-glow min-h-screen">
      <nav className="mx-auto flex max-w-6xl items-center justify-between p-5">
        <div className="flex items-center gap-2 text-lg font-bold"><Workflow className="text-indigo-500" /> BuildGuard AI</div>
        <div className="flex items-center gap-2">
          <button className="btn-ghost !p-2" onClick={() => setDark(!dark)}>{dark ? <Sun size={16} /> : <Moon size={16} />}</button>
          {user ? <Link to="/dashboard" className="btn-primary">Open dashboard</Link> : <><Link to="/login" className="btn-ghost">Log in</Link><Link to="/register" className="btn-primary">Get started</Link></>}
        </div>
      </nav>
      <section className="mx-auto max-w-4xl px-5 py-20 text-center animate-fade">
        <span className="badge bg-indigo-500/15 text-indigo-500"><Sparkles size={12} className="mr-1" />CSE Minor Project - Jenkins + Claude AI</span>
        <h1 className="mt-5 text-4xl font-extrabold leading-tight sm:text-6xl">CI/CD Build Failure Notification System <span className="bg-gradient-to-r from-indigo-500 to-fuchsia-500 bg-clip-text text-transparent">with AI-powered code suggestions</span></h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-slate-500">Stop digging through Jenkins console logs. Get the failed stage, the root cause and a ready-to-review fix the moment a build breaks.</p>
        <div className="mt-8 flex justify-center gap-3"><Link to="/register" className="btn-primary !px-6 !py-3">Create free account</Link><Link to="/login" className="btn-ghost !px-6 !py-3">Try the demo</Link></div>
        <p className="mt-3 text-xs text-slate-500">Demo login: admin@demo.dev / Admin@123</p>
      </section>
      <section className="mx-auto grid max-w-6xl gap-4 px-5 pb-20 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map(([Icon, t, d], i) => (
          <div key={t} className="card animate-fade transition hover:-translate-y-1 hover:shadow-lg" style={{ animationDelay: `${i * 70}ms` }}>
            <Icon className="mb-3 text-indigo-500" /><h3 className="font-semibold">{t}</h3><p className="mt-1 text-sm text-slate-500">{d}</p></div>))}
      </section>
      <footer className="pb-8 text-center text-xs text-slate-500">Department of CSE - School of Computing - Minor Project I</footer>
    </div>
  );
}
