import { useState } from "react";
import { Moon, Sun } from "lucide-react";
import { api, useLoad } from "../api";
import { useApp } from "../context";
import { Badge, Card, CopyBtn, ErrorMsg, PageHeader, Spinner } from "../components/ui";

const FORMS = {
  jenkins: { title: "Jenkins server", fields: [["url", "Jenkins URL (e.g. http://localhost:8080)", false], ["user", "Jenkins username", false], ["token", "API token (User > Configure > API Token)", true]] },
  slack: { title: "Slack", fields: [["webhook_url", "Incoming webhook URL", true]] },
  teams: { title: "Microsoft Teams", fields: [["webhook_url", "Workflows / incoming webhook URL", true]] },
  email: { title: "Email recipient", fields: [["to", "Send alerts to (defaults to your login email)", false]] },
};

function Form({ kind, info, reload }) {
  const cfg = FORMS[kind]; const [v, setV] = useState({}); const [msg, setMsg] = useState(""); const [err, setErr] = useState("");
  const save = async (e) => { e.preventDefault(); setErr(""); setMsg(""); try { await api.put(`/integrations/${kind}`, { config: v }); setV({}); setMsg("Saved (encrypted at rest)"); reload(); } catch (x) { setErr(x.message); } };
  const test = async () => { setErr(""); setMsg(""); try { const r = await api.post("/jenkins/test"); setMsg(`Connected - ${r.jobs} job(s) found`); } catch (x) { setErr(x.message); } };
  return (
    <Card><div className="mb-3 flex items-center justify-between"><h3 className="font-semibold">{cfg.title}</h3>{info.configured ? <Badge color="bg-emerald-500/15 text-emerald-600">configured {info.hint}</Badge> : <Badge color="bg-slate-500/15 text-slate-500">not set</Badge>}</div>
      <form onSubmit={save} className="space-y-2">{cfg.fields.map(([k, label, secret]) => (
        <input key={k} className="input" type={secret ? "password" : "text"} placeholder={info[k] && !secret ? `${label} - current: ${info[k]}` : label} value={v[k] || ""} onChange={(e) => setV({ ...v, [k]: e.target.value })} autoComplete="off" />))}
        <div className="flex gap-2"><button className="btn-primary">Save</button>{kind === "jenkins" && <button type="button" className="btn-ghost" onClick={test}>Test connection</button>}</div>
        {msg && <p className="text-sm text-emerald-500">{msg}</p>}<ErrorMsg msg={err} /></form></Card>
  );
}

export default function SettingsPage() {
  const { dark, setDark, user, status } = useApp();
  const { data, loading, reload } = useLoad(() => api.get("/integrations"));
  const hook = `${location.origin.replace("5173", "8000")}/api/webhooks/jenkins`;
  const jf = `post {
  failure {
    script {
      def payload = groovy.json.JsonOutput.toJson([
        job: env.JOB_NAME, build_number: env.BUILD_NUMBER, status: 'FAILURE',
        branch: env.BRANCH_NAME ?: 'main', commit: env.GIT_COMMIT ?: '', build_url: env.BUILD_URL ])
      withCredentials([string(credentialsId: 'buildguard-token', variable: 'TOKEN')]) {
        sh "curl -s -X POST ${hook} -H 'Content-Type: application/json' -H 'X-Jenkins-Token: $TOKEN' -d '\${payload}'"
      }
    }
  }
}`;
  return (
    <>
      <PageHeader title="Settings" sub="Appearance, Jenkins connection and notification channels" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card><h3 className="mb-3 font-semibold">Profile & appearance</h3><p className="text-sm">{user.name} - {user.email} <Badge>{user.role}</Badge></p>
          <button className="btn-ghost mt-3" onClick={() => setDark(!dark)}>{dark ? <Sun size={14} /> : <Moon size={14} />}{dark ? "Switch to light" : "Switch to dark"} theme</button>
          <div className="mt-4 space-y-1 text-sm text-slate-500"><div>AI engine: <b>{status?.ai_live ? `Claude (${status.ai_model})` : "Demo rule engine (no API key)"}</b></div>
            <div>SMTP email: <b>{status?.smtp ? "configured" : "not configured"}</b></div><div>Jenkins webhook token: <b>{status?.jenkins_webhook ? "configured" : "not set (JENKINS_TOKEN)"}</b></div></div></Card>
        <Card><h3 className="mb-2 font-semibold">Jenkins webhook</h3><p className="text-sm text-slate-500">POST failed builds here with header <code>X-Jenkins-Token</code>. Add this to your Jenkinsfile:</p>
          <div className="mt-2 flex items-center gap-2 text-xs"><code className="break-all">{hook}</code><CopyBtn text={hook} /></div>
          <pre className="mt-2 max-h-48 overflow-auto rounded-lg bg-slate-50 p-3 text-xs dark:bg-slate-950">{jf}</pre><div className="mt-2"><CopyBtn text={jf} /></div></Card>
        {loading ? <Spinner /> : Object.keys(FORMS).map((k) => <Form key={k} kind={k} info={data[k]} reload={reload} />)}
      </div>
    </>
  );
}
