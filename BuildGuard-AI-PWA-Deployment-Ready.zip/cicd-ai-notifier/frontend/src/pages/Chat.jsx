import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Bot, Send, User } from "lucide-react";
import { api, useLoad } from "../api";
import { Card, ErrorMsg, PageHeader, RichText } from "../components/ui";

const QUICK = ["Why did my build fail?", "Explain this error", "Generate corrected code", "How do I fix this dependency issue?",
  "Generate a corrected Jenkinsfile", "How do I fix Docker errors?", "Give me another solution"];

export default function Chat() {
  const [sp] = useSearchParams();
  const { data } = useLoad(() => api.get("/builds?status=failed&limit=100"));
  const [bid, setBid] = useState(sp.get("build") || "");
  const [msgs, setMsgs] = useState([{ role: "assistant", content: "Hi! Pick a failed build and ask me anything about it - I read its Jenkins console log as context." }]);
  const [text, setText] = useState(""); const [busy, setBusy] = useState(false); const [err, setErr] = useState(""); const end = useRef();
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, busy]);
  const send = async (q) => {
    const m = (q ?? text).trim(); if (!m || busy) return; setText(""); setErr("");
    const history = msgs.slice(1); setMsgs([...msgs, { role: "user", content: m }]); setBusy(true);
    try { const r = await api.post("/chat", { message: m, build_id: bid ? Number(bid) : null, history }); setMsgs((x) => [...x, { role: "assistant", content: r.reply }]); }
    catch (e) { setErr(e.message); } finally { setBusy(false); }
  };
  return (
    <>
      <PageHeader title="AI Assistant" sub="Context-aware debugging chat powered by Claude">
        <select className="input !w-64" value={bid} onChange={(e) => setBid(e.target.value)}><option value="">No build context</option>{data?.items.map((b) => <option key={b.id} value={b.id}>#{b.id} - {b.failed_stage || b.status} - {b.branch}</option>)}</select></PageHeader>
      <Card className="flex h-[65vh] flex-col !p-0">
        <div className="flex-1 space-y-4 overflow-auto p-4">{msgs.map((m, i) => (
          <div key={i} className={`flex gap-3 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
            <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${m.role === "user" ? "bg-indigo-600 text-white" : "bg-slate-200 dark:bg-slate-800"}`}>{m.role === "user" ? <User size={16} /> : <Bot size={16} />}</div>
            <div className={`max-w-[85%] rounded-2xl px-4 py-3 ${m.role === "user" ? "bg-indigo-600 text-white" : "bg-slate-100 dark:bg-slate-800"}`}>{m.role === "user" ? <p className="whitespace-pre-wrap text-sm">{m.content}</p> : <RichText text={m.content} />}</div></div>))}
          {busy && <p className="text-sm text-slate-500 animate-pulse">Thinking...</p>}<div ref={end} /></div>
        <div className="border-t border-slate-200 p-3 dark:border-slate-800"><ErrorMsg msg={err} />
          <div className="mb-2 flex flex-wrap gap-2">{QUICK.map((q) => <button key={q} onClick={() => send(q)} className="rounded-full border border-slate-300 px-3 py-1 text-xs hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800">{q}</button>)}</div>
          <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); send(); }}><input className="input" placeholder="Ask about this build..." value={text} maxLength={4000} onChange={(e) => setText(e.target.value)} /><button className="btn-primary" disabled={busy}><Send size={14} /></button></form></div>
      </Card>
    </>
  );
}
