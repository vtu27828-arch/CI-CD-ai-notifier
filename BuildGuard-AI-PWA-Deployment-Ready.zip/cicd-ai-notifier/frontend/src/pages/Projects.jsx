import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FlaskConical, Plus, RefreshCw, Trash2 } from "lucide-react";
import { api, useLoad } from "../api";
import { useApp } from "../context";
import { Card, Empty, ErrorMsg, PageHeader, Spinner } from "../components/ui";

const SCENARIOS = ["python_module", "npm_module", "test_fail", "docker_build", "jenkinsfile_syntax", "deploy", "typescript"];

function Project({ p, reload }) {
  const { status } = useApp();
  const nav = useNavigate();
  const [job, setJob] = useState(""); const [jobs, setJobs] = useState([]);
  const [msg, setMsg] = useState(""); const [err, setErr] = useState(""); const [sc, setSc] = useState(SCENARIOS[0]);
  const run = async (fn, ok) => { setErr(""); setMsg(""); try { const r = await fn(); setMsg(ok ? ok(r) : "Done"); reload(); } catch (e) { setErr(e.message); } };
  return (
    <Card>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div><h3 className="text-lg font-semibold">{p.name}</h3><p className="text-sm text-slate-500">{p.description || "No description"} - {p.build_count} builds</p></div>
        <button className="btn-ghost text-rose-500" onClick={() => confirm("Delete project and all its builds?") && run(() => api.del(`/projects/${p.id}`))}><Trash2 size={14} /></button>
      </div>
      <div className="mt-4 space-y-2">
        {p.repositories.length ? p.repositories.map((r) => (
          <div key={r.id} className="flex items-center justify-between rounded-lg border border-slate-200 p-3 text-sm dark:border-slate-800">
            <div><b>{r.full_name}</b><div className="text-xs text-slate-500">Jenkins job - branch {r.default_branch}</div></div>
            <div className="flex gap-2"><button className="btn-ghost !py-1" onClick={() => run(() => api.post(`/repositories/${r.id}/sync`), (x) => `Imported ${x.imported} new of ${x.total} builds`)}><RefreshCw size={14} />Sync</button>
              <button className="btn-ghost !py-1 text-rose-500" onClick={() => run(() => api.del(`/repositories/${r.id}`))}><Trash2 size={14} /></button></div></div>
        )) : <Empty text="No Jenkins job connected yet" />}
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <input className="input !w-auto min-w-[200px] flex-1" placeholder="Jenkins job name (e.g. folder/payments-api)" value={job} onChange={(e) => setJob(e.target.value)} list={`jobs-${p.id}`} />
        <datalist id={`jobs-${p.id}`}>{jobs.map((j) => <option key={j.full_name} value={j.full_name} />)}</datalist>
        <button className="btn-ghost" onClick={() => run(async () => setJobs(await api.get("/jenkins/jobs")), (x) => "Loaded jobs from Jenkins - pick one in the box")}>Load from Jenkins</button>
        <button className="btn-primary" disabled={!job} onClick={() => run(async () => { await api.post("/repositories", { project_id: p.id, full_name: job }); setJob(""); })}><Plus size={14} />Connect job</button>
      </div>
      {status?.demo_mode && (
        <div className="mt-4 flex flex-wrap items-center gap-2 rounded-lg border border-dashed border-amber-500/50 p-3 text-sm">
          <FlaskConical size={16} className="text-amber-500" /><span className="font-medium">Demo:</span>
          <select className="input !w-auto" value={sc} onChange={(e) => setSc(e.target.value)}>{SCENARIOS.map((s) => <option key={s}>{s}</option>)}</select>
          <button className="btn-ghost" onClick={() => run(async () => { const b = await api.post("/builds/simulate", { project_id: p.id, scenario: sc }); nav(`/logs/${b.id}`); })}>Simulate failed build</button>
        </div>)}
      {msg && <p className="mt-3 text-sm text-emerald-500">{msg}</p>}<div className="mt-3"><ErrorMsg msg={err} /></div>
    </Card>
  );
}

export default function Projects() {
  const { data, loading, reload } = useLoad(() => api.get("/projects"));
  const [f, setF] = useState({ name: "", description: "" }); const [err, setErr] = useState("");
  const create = async (e) => { e.preventDefault(); setErr(""); try { await api.post("/projects", f); setF({ name: "", description: "" }); reload(); } catch (x) { setErr(x.message); } };
  return (
    <>
      <PageHeader title="Projects & Jenkins" sub="Link Jenkins jobs to projects. Builds arrive via the Jenkinsfile webhook or the Sync button (Jenkins credentials: Settings)." />
      <Card className="mb-4"><form onSubmit={create} className="flex flex-wrap gap-2">
        <input className="input !w-auto flex-1" placeholder="Project name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required minLength={2} />
        <input className="input !w-auto flex-[2]" placeholder="Description (optional)" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        <button className="btn-primary"><Plus size={14} />New project</button></form><div className="mt-2"><ErrorMsg msg={err} /></div></Card>
      {loading ? <Spinner /> : <div className="space-y-4">{data.length ? data.map((p) => <Project key={p.id} p={p} reload={reload} />) : <Empty text="Create your first project above" />}</div>}
    </>
  );
}
