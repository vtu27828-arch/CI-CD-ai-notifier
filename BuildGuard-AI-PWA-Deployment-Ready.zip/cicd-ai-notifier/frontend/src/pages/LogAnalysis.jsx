import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { MessageSquare, Sparkles, Upload } from "lucide-react";
import { api, useLoad } from "../api";
import { Badge, Card, Empty, ErrorMsg, PageHeader, Spinner, StatusBadge, STAGES, fmt } from "../components/ui";

function Viewer({ b }) {
  const [onlyErr, setOnlyErr] = useState(false);
  const errLines = useMemo(() => new Set((b.failure?.error_lines || []).map((e) => e.line)), [b]);
  const lines = b.log.split("\n");
  const ref = useRef();
  const jump = (n) => ref.current?.querySelector(`[data-l="${n}"]`)?.scrollIntoView({ block: "center", behavior: "smooth" });
  return (
    <div className="grid gap-4 xl:grid-cols-3">
      <Card className="xl:col-span-2 !p-0"><div className="flex items-center justify-between border-b border-slate-200 p-3 dark:border-slate-800">
        <h3 className="font-semibold">Complete build log <span className="text-xs font-normal text-slate-500">({lines.length} lines, {errLines.size} flagged)</span></h3>
        <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={onlyErr} onChange={(e) => setOnlyErr(e.target.checked)} />Errors only</label></div>
        <div ref={ref} className="max-h-[520px] overflow-auto bg-slate-50 py-2 font-mono text-xs dark:bg-slate-950">
          {lines.map((l, i) => (!onlyErr || errLines.has(i + 1)) && (
            <div key={i} data-l={i + 1} className={`flex gap-3 px-3 py-0.5 ${errLines.has(i + 1) ? "bg-rose-500/15 text-rose-600 dark:text-rose-300" : ""} ${b.failure?.error_message && l.includes(b.failure.error_message.slice(0, 40)) ? "!bg-rose-500/30 font-bold" : ""}`}>
              <span className="w-8 shrink-0 select-none text-right text-slate-400">{i + 1}</span><span className="whitespace-pre-wrap break-all">{l}</span></div>))}</div></Card>
      <Card><h3 className="mb-3 font-semibold">Error messages & timestamps</h3>
        {b.failure?.error_lines?.length ? <div className="max-h-[520px] space-y-2 overflow-auto">{b.failure.error_lines.map((e) => (
          <button key={e.line} onClick={() => jump(e.line)} className="block w-full rounded-lg border border-slate-200 p-2 text-left text-xs hover:border-rose-400 dark:border-slate-800">
            <div className="mb-1 flex justify-between text-slate-500"><span>line {e.line}</span><span>{e.timestamp || ""}</span></div><div className="break-all font-mono">{e.text}</div></button>))}</div> : <Empty text="No error lines detected" />}</Card>
    </div>
  );
}

export default function LogAnalysis() {
  const { id } = useParams(); const nav = useNavigate();
  const builds = useLoad(() => api.get("/builds?limit=100"));
  const projects = useLoad(() => api.get("/projects"));
  const { data: b, loading, reload } = useLoad(() => (id ? api.get(`/builds/${id}`) : Promise.resolve(null)), [id]);
  const [pid, setPid] = useState(""); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const pending = b && b.status === "failed" && !b.analysis;
  useEffect(() => { if (!pending) return; const t = setInterval(reload, 2500); return () => clearInterval(t); }, [pending]); // poll until AI finishes

  const upload = async (e) => {
    const file = e.target.files[0]; if (!file) return; setErr(""); setBusy(true);
    try { const fd = new FormData(); fd.append("file", file); fd.append("project_id", pid || projects.data?.[0]?.id); const r = await api.upload("/builds/upload", fd); nav(`/logs/${r.id}`); }
    catch (x) { setErr(x.message); } finally { setBusy(false); e.target.value = ""; }
  };
  return (
    <>
      <PageHeader title="Build Log Analysis" sub="Inspect logs, failed stage, error lines - or upload a log file (.log / .txt, max 2 MB)">
        <select className="input !w-56" value={id || ""} onChange={(e) => e.target.value && nav(`/logs/${e.target.value}`)}>
          <option value="">Select a build...</option>{builds.data?.items.map((x) => <option key={x.id} value={x.id}>#{x.id} - {x.status} - {x.branch || x.workflow}</option>)}</select>
        {projects.data?.length > 1 && <select className="input !w-40" value={pid} onChange={(e) => setPid(e.target.value)}>{projects.data.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>}
        <label className={`btn-primary cursor-pointer ${!projects.data?.length ? "opacity-50" : ""}`}><Upload size={14} />{busy ? "Uploading..." : "Upload log"}<input type="file" accept=".log,.txt" hidden onChange={upload} disabled={!projects.data?.length || busy} /></label>
      </PageHeader>
      <ErrorMsg msg={err} />
      {!id && <Card><Empty text="Select a build above, or upload a log file to analyse it." /></Card>}
      {id && loading && !b && <Spinner />}
      {b && (<div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {[["Build", `#${b.id}`], ["Status", <StatusBadge s={b.status} />], ["Failed stage", b.failed_stage ? <Badge color="bg-rose-500/15 text-rose-500">{STAGES[b.failed_stage]}</Badge> : "-"],
            ["Category", b.failure?.category || "-"], ["Failure time", fmt(b.failure?.detected_at)]].map(([k, v]) => <Card key={k}><div className="text-xs text-slate-500">{k}</div><div className="mt-1 font-semibold">{v}</div></Card>)}</div>
        {b.error_message && <Card className="border-rose-500/40"><div className="text-xs text-slate-500">Primary error</div><code className="break-all text-rose-500">{b.error_message}</code>
          <div className="mt-1 text-xs text-slate-500">{b.repository || b.project_name} - {b.branch} - {b.commit_sha?.slice(0, 7)} {b.commit_message && `- ${b.commit_message}`}</div></Card>}
        {b.analysis ? <Card><div className="flex flex-wrap items-center justify-between gap-2"><h3 className="flex items-center gap-2 font-semibold"><Sparkles size={16} className="text-indigo-500" />AI summary {b.analysis.demo && <Badge color="bg-amber-500/15 text-amber-600">demo</Badge>}</h3>
          <div className="flex gap-2"><Link className="btn-primary" to={`/suggestions/${b.id}`}>View code suggestions</Link><Link className="btn-ghost" to={`/chat?build=${b.id}`}><MessageSquare size={14} />Ask AI</Link></div></div>
          <p className="mt-2 text-sm"><b>Root cause:</b> {b.analysis.result.root_cause}</p><p className="mt-1 text-sm text-slate-500">{b.analysis.result.explanation}</p></Card>
          : pending && <Card><div className="flex items-center gap-2 text-sm"><Spinner />AI analysis in progress...</div></Card>}
        {b.log ? <Viewer b={b} /> : <Card><Empty text="No log stored for this build" /></Card>}
      </div>)}
    </>
  );
}
