import { useState } from "react";
import { Trash2 } from "lucide-react";
import { api, useLoad } from "../api";
import { Card, Empty, ErrorMsg, PageHeader, Spinner } from "../components/ui";

const TABS = ["users", "projects", "repositories", "builds", "failures", "analyses", "notifications", "activity"];
const DEL = ["users", "projects", "repositories", "builds", "notifications"];
const cell = (v) => { const s = typeof v === "object" && v !== null ? JSON.stringify(v) : String(v ?? ""); return s.length > 60 ? s.slice(0, 60) + "..." : s; };

export default function Admin() {
  const [tab, setTab] = useState("users"); const [err, setErr] = useState("");
  const stats = useLoad(() => api.get("/admin/stats"));
  const { data, loading, reload } = useLoad(() => api.get(`/admin/${tab}`), [tab]);
  const act = async (fn) => { setErr(""); try { await fn(); reload(); stats.reload(); } catch (e) { setErr(e.message); } };
  const cols = data?.[0] ? Object.keys(data[0]).filter((k) => !["log"].includes(k)) : [];
  return (
    <>
      <PageHeader title="Admin Panel" sub="Manage users, projects, jobs, builds, failures, notifications and activity" />
      <div className="mb-4 flex flex-wrap gap-2">{TABS.map((t) => (
        <button key={t} onClick={() => setTab(t)} className={`rounded-lg px-3 py-2 text-sm capitalize ${t === tab ? "bg-indigo-600 text-white" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"}`}>{t} <span className="opacity-70">({stats.data?.[t] ?? "-"})</span></button>))}</div>
      <ErrorMsg msg={err} />
      <Card className="mt-2 overflow-x-auto !p-0">{loading ? <Spinner /> : !data.length ? <Empty text="No records" /> : (
        <table className="w-full"><thead><tr className="border-b border-slate-200 dark:border-slate-800">{cols.map((c) => <th key={c} className="th">{c}</th>)}<th className="th">Actions</th></tr></thead>
          <tbody>{data.map((r) => (<tr key={r.id} className="border-b border-slate-100 dark:border-slate-800/60">
            {cols.map((c) => <td key={c} className="td whitespace-nowrap text-xs">{cell(r[c])}</td>)}
            <td className="td whitespace-nowrap">
              {tab === "users" && <><button className="btn-ghost !py-1 text-xs" onClick={() => act(() => api.patch(`/admin/users/${r.id}`, { role: r.role === "admin" ? "user" : "admin" }))}>{r.role === "admin" ? "Demote" : "Make admin"}</button>{" "}
                <button className="btn-ghost !py-1 text-xs" onClick={() => act(() => api.patch(`/admin/users/${r.id}`, { is_active: !r.is_active }))}>{r.is_active ? "Disable" : "Enable"}</button>{" "}</>}
              {DEL.includes(tab) && <button className="btn-ghost !py-1 text-rose-500" onClick={() => confirm("Delete this record?") && act(() => api.del(`/admin/${tab}/${r.id}`))}><Trash2 size={13} /></button>}</td></tr>))}</tbody></table>)}</Card>
    </>
  );
}
