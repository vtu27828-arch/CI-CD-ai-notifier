import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Download, RefreshCw, ShieldCheck } from "lucide-react";
import { api, useLoad } from "../api";
import { Badge, Card, CodeEditor, CopyBtn, Empty, ErrorMsg, PageHeader, Spinner, StatusBadge, download, STAGES } from "../components/ui";

function artifacts(r) {
  const a = [];
  if (r.generated_code?.code) a.push({ key: "code", label: "Generated code", name: r.generated_code.filename || "fix.txt", lang: r.generated_code.language, text: r.generated_code.code, note: r.generated_code.explanation });
  if (r.dependency_fix?.content) a.push({ key: "dep", label: r.dependency_fix.filename || "Dependencies", name: r.dependency_fix.filename || "deps.txt", lang: r.dependency_fix.filename?.endsWith(".json") ? "json" : "bash", text: r.dependency_fix.content, note: "Updated dependency file" });
  (r.config_files || []).forEach((c, i) => a.push({ key: "cfg" + i, label: c.filename, name: c.filename, lang: c.language, text: c.content, note: "Updated configuration file" }));
  if (r.fixed_pipeline) a.push({ key: "jf", label: "Jenkinsfile", name: "Jenkinsfile", lang: "groovy", text: r.fixed_pipeline, note: "Corrected Jenkins declarative pipeline" });
  return a;
}

function Detail({ id }) {
  const { data: b, loading, reload } = useLoad(() => api.get(`/builds/${id}`), [id]);
  const [tab, setTab] = useState(0); const [edits, setEdits] = useState({}); const [fb, setFb] = useState(""); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  useEffect(() => { setTab(0); setEdits({}); }, [b?.analysis?.id]);
  if (loading && !b) return <Spinner />;
  if (!b?.analysis) return <Card><Empty text="No AI analysis for this build yet." /></Card>;
  const r = b.analysis.result; const arts = artifacts(r); const cur = arts[tab]; const text = cur ? edits[cur.key] ?? cur.text : "";
  const regen = async () => { setBusy(true); setErr(""); try { await api.post(`/builds/${id}/analysis/regenerate`, { feedback: fb }); setFb(""); await reload(); } catch (e) { setErr(e.message); } finally { setBusy(false); } };
  return (
    <div className="space-y-4">
      <Card><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold">Build #{b.id} - {b.project_name}</h3><StatusBadge s={b.status} />{b.failed_stage && <Badge color="bg-rose-500/15 text-rose-500">{STAGES[b.failed_stage]}</Badge>}
        <Badge>v{b.analysis.version}</Badge>{b.analysis.demo ? <Badge color="bg-amber-500/15 text-amber-600">demo engine</Badge> : <Badge color="bg-emerald-500/15 text-emerald-600">Claude: {b.analysis.model}</Badge>}</div>
        <div className="mt-3 text-xs text-slate-500">Original error</div><code className="block break-all rounded-lg bg-rose-500/10 p-2 text-sm text-rose-500">{b.error_message}</code></Card>
      <div className="grid gap-4 md:grid-cols-2">
        <Card><div className="text-xs font-semibold uppercase text-slate-500">Root cause</div><p className="mt-1 text-sm">{r.root_cause}</p><p className="mt-2 text-sm text-slate-500">{r.explanation}</p></Card>
        <Card><div className="text-xs font-semibold uppercase text-slate-500">Suggested solution</div><p className="mt-1 text-sm">{r.solution}</p>
          {r.debugging_steps?.length > 0 && <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm text-slate-500">{r.debugging_steps.map((s, i) => <li key={i}>{s}</li>)}</ol>}</Card>
      </div>
      {arts.length > 0 && <Card>
        <div className="mb-3 flex flex-wrap gap-2">{arts.map((a, i) => <button key={a.key} onClick={() => setTab(i)} className={`rounded-lg px-3 py-1.5 text-sm ${i === tab ? "bg-indigo-600 text-white" : "bg-slate-100 dark:bg-slate-800"}`}>{a.label}</button>)}</div>
        <CodeEditor value={text} onChange={(v) => setEdits({ ...edits, [cur.key]: v })} language={cur.lang} />
        <p className="mt-2 text-sm text-slate-500"><b>Explanation:</b> {cur.note}</p>
        <div className="mt-3 flex flex-wrap gap-2"><CopyBtn text={text} /><button className="btn-ghost !py-1 text-xs" onClick={() => download(cur.name.split("/").pop(), text)}><Download size={14} />Download</button></div>
        <p className="mt-3 flex items-start gap-2 rounded-lg bg-emerald-500/10 p-3 text-xs text-emerald-600 dark:text-emerald-400"><ShieldCheck size={16} className="shrink-0" />Review before applying. This tool never modifies your repository or runs AI-generated code - copy or download it and apply it yourself.</p></Card>}
      {r.prevention?.length > 0 && <Card><div className="text-xs font-semibold uppercase text-slate-500">How to prevent this</div><ul className="mt-2 list-disc space-y-1 pl-5 text-sm">{r.prevention.map((p, i) => <li key={i}>{p}</li>)}</ul></Card>}
      <Card><div className="flex flex-wrap gap-2"><input className="input !w-auto flex-1" placeholder="Optional hint, e.g. 'we use Poetry'" value={fb} maxLength={500} onChange={(e) => setFb(e.target.value)} />
        <button className="btn-primary" onClick={regen} disabled={busy}><RefreshCw size={14} className={busy ? "animate-spin" : ""} />Regenerate solution</button></div><div className="mt-2"><ErrorMsg msg={err} /></div></Card>
    </div>
  );
}

export default function Suggestions() {
  const { id } = useParams();
  const { data: list, loading } = useLoad(() => api.get("/suggestions"));
  const sel = id || list?.[0]?.id;
  return (
    <>
      <PageHeader title="AI Code Suggestions" sub="Review AI-generated fixes for failed builds" />
      {loading ? <Spinner /> : !list.length ? <Card><Empty text="No analysed failures yet." /></Card> : (
        <div className="grid gap-4 lg:grid-cols-4">
          <div className="max-h-[75vh] space-y-2 overflow-auto lg:col-span-1">{list.map((b) => (
            <Link key={b.id} to={`/suggestions/${b.id}`} className={`block rounded-xl border p-3 text-sm transition ${String(sel) === String(b.id) ? "border-indigo-500 bg-indigo-500/10" : "border-slate-200 hover:border-indigo-400 dark:border-slate-800"}`}>
              <div className="font-semibold">Build #{b.id}</div><div className="truncate text-xs text-slate-500">{b.root_cause}</div></Link>))}</div>
          <div className="lg:col-span-3">{sel && <Detail id={sel} key={sel} />}</div></div>)}
    </>
  );
}
