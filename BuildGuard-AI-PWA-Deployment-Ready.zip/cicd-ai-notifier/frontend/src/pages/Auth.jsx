import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { Workflow } from "lucide-react";
import { useApp } from "../context";
import { ErrorMsg } from "../components/ui";

export default function Auth({ mode }) {
  const { user, authenticate, status } = useApp();
  const nav = useNavigate();
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/dashboard" replace />;
  const reg = mode === "register";
  const submit = async (e) => {
    e.preventDefault(); setErr(""); setBusy(true);
    try { await authenticate(mode, reg ? f : { email: f.email, password: f.password }); nav("/dashboard"); }
    catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <div className="hero-glow flex min-h-screen items-center justify-center p-4">
      <form onSubmit={submit} className="card w-full max-w-md space-y-4 animate-fade">
        <div className="flex items-center gap-2 text-xl font-bold"><Workflow className="text-indigo-500" /> BuildGuard AI</div>
        <h2 className="text-lg font-semibold">{reg ? "Create your account" : "Welcome back"}</h2>
        {reg && <input className="input" placeholder="Full name" value={f.name} onChange={set("name")} required minLength={2} />}
        <input className="input" type="email" placeholder="Email" value={f.email} onChange={set("email")} required />
        <input className="input" type="password" placeholder={reg ? "Password (8+ chars, letters & digits)" : "Password"} value={f.password} onChange={set("password")} required minLength={reg ? 8 : 1} />
        <ErrorMsg msg={err} />
        <button className="btn-primary w-full" disabled={busy}>{busy ? "Please wait..." : reg ? "Register" : "Log in"}</button>
        {status?.demo_mode && !reg && <button type="button" className="btn-ghost w-full text-xs" onClick={() => setF({ ...f, email: "admin@demo.dev", password: "Admin@123" })}>Fill demo admin credentials</button>}
        <p className="text-center text-sm text-slate-500">{reg ? <>Have an account? <Link className="text-indigo-500" to="/login">Log in</Link></> : <>New here? <Link className="text-indigo-500" to="/register">Register</Link></>}</p>
      </form>
    </div>
  );
}
