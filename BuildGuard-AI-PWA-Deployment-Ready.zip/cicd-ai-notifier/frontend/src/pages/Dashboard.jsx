import { Link } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Area, AreaChart } from "recharts";
import { Activity, CheckCircle2, Clock, Percent, Sparkles, XCircle, Layers } from "lucide-react";
import { api, useLoad } from "../api";
import { Card, Empty, PageHeader, Spinner, StatusBadge, STAGES, fmt } from "../components/ui";

const Stat = ({ icon: Icon, label, value, color }) => (
  <Card className="flex items-center gap-4 transition hover:-translate-y-0.5">
    <div className={`rounded-xl p-3 ${color}`}><Icon size={22} /></div>
    <div><div className="text-2xl font-bold">{value}</div><div className="text-xs text-slate-500">{label}</div></div></Card>
);

export default function Dashboard() {
  const { data: d, loading, error } = useLoad(() => api.get("/dashboard"));
  if (loading) return <Spinner />;
  if (error) return <p className="text-rose-500">{error}</p>;
  const pie = [{ name: "Success", value: d.success, c: "#10b981" }, { name: "Failed", value: d.failed, c: "#f43f5e" }, { name: "Running", value: d.running, c: "#0ea5e9" }].filter((x) => x.value);
  const stage = d.by_stage.map((s) => ({ ...s, name: STAGES[s.name] || s.name }));
  return (
    <>
      <PageHeader title="Dashboard" sub="Live overview of your Jenkins pipelines (data from the database)" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <Stat icon={Layers} label="Total builds" value={d.total} color="bg-indigo-500/15 text-indigo-500" />
        <Stat icon={CheckCircle2} label="Successful" value={d.success} color="bg-emerald-500/15 text-emerald-500" />
        <Stat icon={XCircle} label="Failed" value={d.failed} color="bg-rose-500/15 text-rose-500" />
        <Stat icon={Clock} label="Running" value={d.running} color="bg-sky-500/15 text-sky-500" />
        <Stat icon={Percent} label="Success rate" value={`${d.success_pct}%`} color="bg-emerald-500/15 text-emerald-500" />
        <Stat icon={Activity} label="Failure rate" value={`${d.failure_pct}%`} color="bg-rose-500/15 text-rose-500" />
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2"><h3 className="mb-3 font-semibold">Builds - last 7 days</h3>
          <ResponsiveContainer width="100%" height={250}><AreaChart data={d.trend}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.2} /><XAxis dataKey="day" fontSize={12} /><YAxis allowDecimals={false} fontSize={12} /><Tooltip /><Legend />
            <Area type="monotone" dataKey="success" stroke="#10b981" fill="#10b98133" /><Area type="monotone" dataKey="failed" stroke="#f43f5e" fill="#f43f5e33" /></AreaChart></ResponsiveContainer></Card>
        <Card><h3 className="mb-3 font-semibold">Build outcome</h3>
          {pie.length ? <ResponsiveContainer width="100%" height={250}><PieChart><Pie data={pie} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={3}>
            {pie.map((p) => <Cell key={p.name} fill={p.c} />)}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer> : <Empty text="No builds yet" />}</Card>
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card><h3 className="mb-3 font-semibold">Failures by stage</h3>
          {stage.length ? <ResponsiveContainer width="100%" height={220}><BarChart data={stage} layout="vertical"><CartesianGrid strokeDasharray="3 3" opacity={0.2} />
            <XAxis type="number" allowDecimals={false} fontSize={12} /><YAxis type="category" dataKey="name" width={110} fontSize={11} /><Tooltip /><Bar dataKey="count" fill="#6366f1" radius={4} /></BarChart></ResponsiveContainer> : <Empty text="No failures" />}</Card>
        <Card className="lg:col-span-2"><h3 className="mb-3 font-semibold">Repository / Jenkins job status</h3>
          {d.repos.length ? <div className="space-y-2">{d.repos.map((r) => (
            <div key={r.id} className="flex items-center justify-between rounded-lg border border-slate-200 p-3 text-sm dark:border-slate-800">
              <div><b>{r.full_name}</b><div className="text-xs text-slate-500">{r.builds} builds - {r.failed} failed {r.last_branch && `- ${r.last_branch}`}</div></div><StatusBadge s={r.last_status} /></div>))}</div> : <Empty text="Connect a Jenkins job in Projects" />}</Card>
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card><h3 className="mb-3 font-semibold">Recent build activity</h3>
          {d.recent.length ? <div className="divide-y divide-slate-200 dark:divide-slate-800">{d.recent.map((b) => (
            <Link key={b.id} to={`/logs/${b.id}`} className="flex items-center justify-between py-2.5 text-sm hover:text-indigo-500">
              <div><b>#{b.id}</b> {b.project_name} <span className="text-slate-500">- {b.branch || "-"}</span><div className="text-xs text-slate-500">{fmt(b.created_at)}</div></div><StatusBadge s={b.status} /></Link>))}</div> : <Empty text="No builds yet" />}</Card>
        <Card><h3 className="mb-3 flex items-center gap-2 font-semibold"><Sparkles size={16} className="text-indigo-500" />AI-generated suggestions</h3>
          {d.suggestions.length ? <div className="space-y-3">{d.suggestions.map((s) => (
            <Link key={s.build_id} to={`/suggestions/${s.build_id}`} className="block rounded-lg border border-slate-200 p-3 text-sm transition hover:border-indigo-500 dark:border-slate-800">
              <div className="font-medium">Build #{s.build_id} - {s.root_cause}</div><div className="mt-1 text-xs text-slate-500">{s.solution}</div></Link>))}</div> : <Empty text="No AI analyses yet" />}</Card>
      </div>
    </>
  );
}
