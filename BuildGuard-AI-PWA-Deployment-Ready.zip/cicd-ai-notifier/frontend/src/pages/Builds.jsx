import { useState } from "react";
import { Link } from "react-router-dom";
import { Search } from "lucide-react";
import { api, useLoad } from "../api";
import { Badge, Card, Empty, PageHeader, Spinner, StatusBadge, STAGES, fmt } from "../components/ui";

export default function Builds() {
  const [f, setF] = useState({ search: "", status: "", stage: "", branch: "" });
  const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
  const { data, loading } = useLoad(() => api.get("/builds?" + qs), [qs]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <>
      <PageHeader title="Build History" sub="Every Jenkins build with its failure details and AI analysis" />
      <Card className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="relative"><Search size={14} className="absolute left-3 top-3 text-slate-400" /><input className="input !pl-9" placeholder="Search commit, error, message..." value={f.search} onChange={set("search")} /></div>
        <select className="input" value={f.status} onChange={set("status")}><option value="">All statuses</option>{["success", "failed", "running", "cancelled"].map((s) => <option key={s}>{s}</option>)}</select>
        <select className="input" value={f.stage} onChange={set("stage")}><option value="">All failed stages</option>{Object.entries(STAGES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        <input className="input" placeholder="Branch" value={f.branch} onChange={set("branch")} />
      </Card>
      <Card className="overflow-x-auto !p-0">
        {loading ? <Spinner /> : !data.items.length ? <Empty text="No builds match your filters" /> : (
          <table className="w-full"><thead><tr className="border-b border-slate-200 dark:border-slate-800">
            {["Build", "Job / Repository", "Branch", "Commit", "Status", "Time", "Failed stage / Error", "AI"].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
            <tbody>{data.items.map((b) => (
              <tr key={b.id} className="border-b border-slate-100 hover:bg-slate-50 dark:border-slate-800/60 dark:hover:bg-slate-800/40">
                <td className="td"><Link className="font-semibold text-indigo-500" to={`/logs/${b.id}`}>#{b.id}</Link></td>
                <td className="td">{b.repository || b.project_name}</td><td className="td">{b.branch || "-"}</td>
                <td className="td font-mono text-xs">{(b.commit_sha || "").slice(0, 7) || "-"}</td><td className="td"><StatusBadge s={b.status} /></td>
                <td className="td text-xs text-slate-500">{fmt(b.created_at)}{b.duration_s != null && <div>{b.duration_s}s</div>}</td>
                <td className="td max-w-xs">{b.failed_stage ? <><Badge color="bg-rose-500/15 text-rose-500">{STAGES[b.failed_stage]}</Badge><div className="mt-1 truncate text-xs text-slate-500" title={b.error_message}>{b.error_message}</div></> : "-"}</td>
                <td className="td">{b.has_analysis ? <Link to={`/suggestions/${b.id}`} className="text-indigo-500 text-xs">View fix</Link> : "-"}</td></tr>))}</tbody></table>)}
      </Card>
      {data && <p className="mt-2 text-xs text-slate-500">{data.total} build(s)</p>}
    </>
  );
}
