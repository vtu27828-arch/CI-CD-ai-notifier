from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Build, Failure, Notification, Project, to_dict, now
from ..security import current_user
from ..services import notify
from .builds import own_build

router = APIRouter(prefix="/api/notifications", tags=["notifications"])


@router.get("")
def history(db: Session = Depends(get_db), user=Depends(current_user)):
    rows = (db.query(Notification).join(Build).join(Project).filter(Project.owner_id == user.id)
            .order_by(Notification.id.desc()).limit(200).all())
    return [{**to_dict(n), "project": n.build_id and db.get(Build, n.build_id).project.name} for n in rows]


@router.post("/test/{build_id}")
def resend(build_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    """Re-send the failure notification for a build (also used to test channel setup)."""
    b = own_build(db, build_id, user)
    if not b.failure:
        return {"results": []}
    res = notify.send_all(db, b, b.failure, b.analyses[-1].result if b.analyses else {})
    return {"results": res}
