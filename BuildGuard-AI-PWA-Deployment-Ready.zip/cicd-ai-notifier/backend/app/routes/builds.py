import datetime as dt, random, secrets
from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, HTTPException, Query, UploadFile
from sqlalchemy.orm import Session
from ..config import settings
from ..database import get_db
from ..models import Build, Project, Repository, to_dict, now
from ..security import current_user
from ..services import samples
from ..services.pipeline import log_activity, process_failure, save_log, upsert_build
from .projects import own_project

router = APIRouter(prefix="/api", tags=["builds"])
MAX_UPLOAD = 2 * 1024 * 1024


def build_out(b, detail=False):
    d = to_dict(b)
    d["project_name"] = b.project.name
    d["repository"] = b.repository.full_name if b.repository else None
    d["has_analysis"] = bool(b.analyses)
    if b.analyses:
        d["root_cause"] = b.analyses[-1].result.get("root_cause")
    if b.finished_at and b.started_at:
        d["duration_s"] = int((b.finished_at - b.started_at).total_seconds())
    if detail:
        d["log"] = b.log.content if b.log else ""
        d["failure"] = to_dict(b.failure) if b.failure else None
        d["analysis"] = to_dict(b.analyses[-1]) if b.analyses else None
        d["notifications"] = [to_dict(n) for n in b.notifications]
    return d


def own_build(db, bid, user):
    b = db.get(Build, bid)
    if not b or (b.project.owner_id != user.id and user.role != "admin"):
        raise HTTPException(404, "Build not found")
    return b


def user_builds(db, user):
    return db.query(Build).join(Project).filter(Project.owner_id == user.id)


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), user=Depends(current_user)):
    builds = user_builds(db, user).order_by(Build.created_at.desc()).all()
    c = lambda s: sum(1 for b in builds if b.status == s)
    ok, bad, run = c("success"), c("failed"), c("running")
    done = ok + bad
    days = [(dt.date.today() - dt.timedelta(days=i)) for i in range(6, -1, -1)]
    trend = [{"day": d.strftime("%a %d"), "success": sum(1 for b in builds if b.created_at.date() == d and b.status == "success"),
              "failed": sum(1 for b in builds if b.created_at.date() == d and b.status == "failed")} for d in days]
    by_stage, by_cat = {}, {}
    for b in builds:
        if b.status == "failed" and b.failure:
            by_stage[b.failure.stage] = by_stage.get(b.failure.stage, 0) + 1
            by_cat[b.failure.category] = by_cat.get(b.failure.category, 0) + 1
    repos = []
    for r in db.query(Repository).join(Project).filter(Project.owner_id == user.id):
        rb = sorted(r.builds, key=lambda x: x.created_at, reverse=True)
        repos.append({"id": r.id, "full_name": r.full_name, "provider": r.provider, "builds": len(rb),
                      "failed": sum(1 for x in rb if x.status == "failed"), "last_status": rb[0].status if rb else "none",
                      "last_branch": rb[0].branch if rb else ""})
    sugg = [{"build_id": b.id, "project": b.project.name, "root_cause": b.analyses[-1].result.get("root_cause"),
             "solution": b.analyses[-1].result.get("solution"), "demo": b.analyses[-1].demo}
            for b in builds if b.analyses][:4]
    return {"total": len(builds), "success": ok, "failed": bad, "running": run,
            "success_pct": round(ok / done * 100, 1) if done else 0, "failure_pct": round(bad / done * 100, 1) if done else 0,
            "trend": trend, "by_stage": [{"name": k, "count": v} for k, v in by_stage.items()],
            "by_category": [{"name": k, "count": v} for k, v in by_cat.items()],
            "recent": [build_out(b) for b in builds[:8]], "repos": repos, "suggestions": sugg}


@router.get("/builds")
def list_builds(search: str = "", status: str = "", branch: str = "", stage: str = "", repo_id: int | None = None,
                limit: int = Query(100, le=500), offset: int = 0, db: Session = Depends(get_db), user=Depends(current_user)):
    q = user_builds(db, user)
    if status: q = q.filter(Build.status == status)
    if branch: q = q.filter(Build.branch.ilike(f"%{branch}%"))
    if stage: q = q.filter(Build.failed_stage == stage)
    if repo_id: q = q.filter(Build.repository_id == repo_id)
    if search:
        s = f"%{search}%"
        q = q.filter(Build.commit_sha.ilike(s) | Build.error_message.ilike(s) | Build.commit_message.ilike(s) |
                     Build.branch.ilike(s) | Build.workflow.ilike(s))
    total = q.count()
    rows = q.order_by(Build.created_at.desc()).offset(offset).limit(limit).all()
    return {"total": total, "items": [build_out(b) for b in rows]}


@router.get("/builds/{bid}")
def get_build(bid: int, db: Session = Depends(get_db), user=Depends(current_user)):
    return build_out(own_build(db, bid, user), detail=True)


@router.post("/builds/upload")
async def upload_log(bg: BackgroundTasks, project_id: int = Form(...), branch: str = Form("uploaded"),
                     file: UploadFile = File(...), db: Session = Depends(get_db), user=Depends(current_user)):
    p = own_project(db, project_id, user)
    name = (file.filename or "").lower()
    if not name.endswith((".log", ".txt")):
        raise HTTPException(422, "Only .log or .txt files are accepted")
    raw = await file.read(MAX_UPLOAD + 1)
    if len(raw) > MAX_UPLOAD:
        raise HTTPException(413, "File too large (max 2 MB)")
    if b"\x00" in raw:
        raise HTTPException(422, "Binary files are not allowed")
    b, _ = upsert_build(db, p.id, None, "upload", None, workflow=file.filename[:200], branch=branch[:100] or "uploaded",
                        status="failed", commit_message="Uploaded log file", author=user.name)
    save_log(db, b, raw.decode("utf-8", errors="replace"))
    log_activity(db, user.id, "log_uploaded", file.filename[:100])
    bg.add_task(process_failure, b.id)
    return build_out(b)


@router.post("/builds/simulate")
def simulate(data: dict, bg: BackgroundTasks, db: Session = Depends(get_db), user=Depends(current_user)):
    """DEMO MODE only: creates a fake failed build from a sample log to exercise the full pipeline."""
    if not settings.demo_mode:
        raise HTTPException(403, "Demo mode is disabled")
    p = own_project(db, int(data.get("project_id", 0)), user)
    scenario = data.get("scenario") if data.get("scenario") in samples.SCENARIOS else random.choice(list(samples.SCENARIOS))
    repo = p.repositories[0] if p.repositories else None
    b, _ = upsert_build(db, p.id, repo.id if repo else None, "demo", secrets.token_hex(4), workflow="CI", status="failed",
                        branch=random.choice(["main", "develop", "feature/login"]), commit_sha=secrets.token_hex(20),
                        commit_message=f"Simulated: {scenario}", author=user.name)
    save_log(db, b, samples.make_log(samples.SCENARIOS[scenario]))
    bg.add_task(process_failure, b.id)
    return build_out(b)
