from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import AIAnalysis, Build, Project, to_dict
from ..security import current_user
from ..services import ai
from ..services.analyzer import analyze_log
from .builds import build_out, own_build, user_builds

router = APIRouter(prefix="/api", tags=["ai"])


def _ctx(b):
    text = b.log.content if b.log else ""
    f = b.failure
    failure = {"stage": f.stage, "category": f.category, "message": f.error_message} if f else analyze_log(text)
    return {"meta": {"project": b.project.name, "branch": b.branch, "commit": b.commit_sha, "status": b.status},
            "log": text, "failure": failure, "analysis": b.analyses[-1].result if b.analyses else None}


@router.get("/suggestions")
def suggestions(db: Session = Depends(get_db), user=Depends(current_user)):
    rows = user_builds(db, user).filter(Build.analyses.any()).order_by(Build.created_at.desc()).limit(100).all()
    return [build_out(b) for b in rows]


class RegenIn(BaseModel):
    feedback: str = Field(default="", max_length=500)


@router.post("/builds/{bid}/analysis/regenerate")
def regenerate(bid: int, data: RegenIn, db: Session = Depends(get_db), user=Depends(current_user)):
    b = own_build(db, bid, user)
    c = _ctx(b)
    prev = b.analyses[-1].result if b.analyses else None
    result, model, demo = ai.analyze_build(c["meta"], c["log"], c["failure"], previous=prev, feedback=data.feedback,
                                           variant=len(b.analyses))
    a = AIAnalysis(build_id=b.id, result=result, model=model, demo=demo, version=len(b.analyses) + 1)
    db.add(a); db.commit(); db.refresh(a)
    return to_dict(a)


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    build_id: int | None = None
    history: list[dict] = []


@router.post("/chat")
def chat(data: ChatIn, db: Session = Depends(get_db), user=Depends(current_user)):
    ctx = _ctx(own_build(db, data.build_id, user)) if data.build_id else None
    reply, demo = ai.chat(data.message, data.history, ctx)
    return {"reply": reply, "demo": demo}
