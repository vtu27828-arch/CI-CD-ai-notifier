import httpx
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Integration, Project, Repository, to_dict
from ..security import current_user, encrypt_json, get_integration
from ..services import jenkins
from ..services.pipeline import fetch_and_process, log_activity, upsert_build

router = APIRouter(prefix="/api", tags=["projects"])
JOB_RX = r"^[A-Za-z0-9_.\- /]+$"


class ProjectIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=500)


class RepoIn(BaseModel):  # a "repository" = one Jenkins job (or pipeline) linked to a project
    project_id: int
    full_name: str = Field(pattern=JOB_RX, max_length=200)  # Jenkins job name, e.g. "folder/payments-api"
    default_branch: str = Field(default="main", max_length=100)


def own_project(db, pid, user):
    p = db.get(Project, pid)
    if not p or (p.owner_id != user.id and user.role != "admin"):
        raise HTTPException(404, "Project not found")
    return p


def own_repo(db, rid, user):
    r = db.get(Repository, rid)
    if not r or (r.project.owner_id != user.id and user.role != "admin"):
        raise HTTPException(404, "Job not found")
    return r


def _cfg(db, user):
    c = get_integration(db, user.id, "jenkins")
    if not (c.get("url") and c.get("user") and c.get("token")):
        raise HTTPException(400, "Configure Jenkins URL, user and API token in Settings first")
    return c


def _call(fn):
    try:
        return fn()
    except ValueError as e:
        raise HTTPException(422, str(e))
    except httpx.HTTPStatusError as e:
        raise HTTPException(502, f"Jenkins returned HTTP {e.response.status_code} (check URL / credentials)")
    except httpx.HTTPError:
        raise HTTPException(502, "Could not reach the Jenkins server")


@router.get("/projects")
def list_projects(db: Session = Depends(get_db), user=Depends(current_user)):
    out = []
    for p in db.query(Project).filter_by(owner_id=user.id).order_by(Project.id.desc()):
        d = to_dict(p)
        d["repositories"] = [to_dict(r) for r in p.repositories]
        d["build_count"] = len(p.builds)
        out.append(d)
    return out


@router.post("/projects")
def create_project(data: ProjectIn, db: Session = Depends(get_db), user=Depends(current_user)):
    p = Project(owner_id=user.id, name=data.name.strip(), description=data.description)
    db.add(p); db.commit(); db.refresh(p)
    log_activity(db, user.id, "project_created", p.name)
    return to_dict(p)


@router.delete("/projects/{pid}")
def delete_project(pid: int, db: Session = Depends(get_db), user=Depends(current_user)):
    db.delete(own_project(db, pid, user)); db.commit()
    return {"ok": True}


@router.post("/repositories")
def add_job(data: RepoIn, db: Session = Depends(get_db), user=Depends(current_user)):
    own_project(db, data.project_id, user)
    base = get_integration(db, user.id, "jenkins").get("url", "").rstrip("/")
    r = Repository(project_id=data.project_id, provider="jenkins", full_name=data.full_name.strip("/"),
                   default_branch=data.default_branch, html_url=f"{base}{jenkins.job_path(data.full_name)}/" if base else "")
    db.add(r); db.commit(); db.refresh(r)
    log_activity(db, user.id, "jenkins_job_connected", r.full_name)
    return to_dict(r)


@router.delete("/repositories/{rid}")
def delete_job(rid: int, db: Session = Depends(get_db), user=Depends(current_user)):
    r = own_repo(db, rid, user)
    for b in r.builds:
        b.repository_id = None
    db.delete(r); db.commit()
    return {"ok": True}


@router.get("/jenkins/jobs")
def jenkins_jobs(db: Session = Depends(get_db), user=Depends(current_user)):
    return _call(lambda: jenkins.list_jobs(_cfg(db, user)))


@router.post("/jenkins/test")
def jenkins_test(db: Session = Depends(get_db), user=Depends(current_user)):
    jobs = _call(lambda: jenkins.list_jobs(_cfg(db, user)))
    return {"ok": True, "jobs": len(jobs)}


@router.post("/repositories/{rid}/sync")
def sync_job(rid: int, bg: BackgroundTasks, db: Session = Depends(get_db), user=Depends(current_user)):
    """Import recent Jenkins builds (status, commit, branch) and analyse the failed ones."""
    r = own_repo(db, rid, user)
    cfg = _cfg(db, user)
    builds = _call(lambda: jenkins.list_builds(cfg, r.full_name))
    n = 0
    for b in builds:
        f = jenkins.build_to_fields(r.full_name, b)
        row, created = upsert_build(db, r.project_id, r.id, "jenkins", b["number"], **f)
        if row.status == "failed" and not row.failure:
            bg.add_task(fetch_and_process, row.id, r.full_name, b["number"], cfg)
        n += created
    return {"imported": n, "total": len(builds)}


# ---- Integrations (secrets stored Fernet-encrypted; never returned to the browser) ----
FIELDS = {"jenkins": ["url", "user", "token"], "slack": ["webhook_url"], "teams": ["webhook_url"], "email": ["to"]}
SECRET_FIELD = {"jenkins": "token", "slack": "webhook_url", "teams": "webhook_url", "email": "to"}


@router.get("/integrations")
def integrations(db: Session = Depends(get_db), user=Depends(current_user)):
    out = {}
    for kind in FIELDS:
        cfg = get_integration(db, user.id, kind)
        v = cfg.get(SECRET_FIELD[kind], "")
        out[kind] = {"configured": bool(v), "hint": v if kind == "email" else (("..." + v[-4:]) if v else ""),
                     "url": cfg.get("url", "") if kind == "jenkins" else None, "user": cfg.get("user", "") if kind == "jenkins" else None}
    return out


class IntegrationIn(BaseModel):
    config: dict


@router.put("/integrations/{kind}")
def save_integration(kind: str, data: IntegrationIn, db: Session = Depends(get_db), user=Depends(current_user)):
    if kind not in FIELDS:
        raise HTTPException(404, "Unknown integration")
    i = db.query(Integration).filter_by(user_id=user.id, kind=kind).first() or Integration(user_id=user.id, kind=kind)
    old = {}
    if i.config_enc:
        from ..security import decrypt_json
        old = decrypt_json(i.config_enc)
    cfg = {k: (str(data.config.get(k, "")).strip()[:500] or old.get(k, "")) for k in FIELDS[kind]}  # blank secret = keep old
    if kind in ("slack", "teams") and cfg["webhook_url"] and not cfg["webhook_url"].startswith("https://"):
        raise HTTPException(422, "Webhook URL must start with https://")
    if kind == "jenkins" and cfg["url"] and not cfg["url"].startswith(("http://", "https://")):
        raise HTTPException(422, "Jenkins URL must start with http:// or https://")
    i.config_enc = encrypt_json(cfg)
    db.add(i); db.commit()
    log_activity(db, user.id, "integration_saved", kind)
    return {"ok": True}
