from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import (AIAnalysis, Activity, Build, Failure, Notification, Project, Repository, User, to_dict)
from ..security import admin_user
from ..services.pipeline import log_activity

router = APIRouter(prefix="/api/admin", tags=["admin"])
ENTITIES = {"users": User, "projects": Project, "repositories": Repository, "builds": Build, "failures": Failure,
            "notifications": Notification, "analyses": AIAnalysis, "activity": Activity}
DELETABLE = {"users", "projects", "repositories", "builds", "notifications"}


@router.get("/stats")
def stats(db: Session = Depends(get_db), _=Depends(admin_user)):
    return {k: db.query(m).count() for k, m in ENTITIES.items()}


@router.get("/{entity}")
def rows(entity: str, db: Session = Depends(get_db), _=Depends(admin_user)):
    m = ENTITIES.get(entity)
    if not m:
        raise HTTPException(404, "Unknown entity")
    out = []
    for o in db.query(m).order_by(m.id.desc()).limit(200):
        d = to_dict(o)
        if entity == "analyses":
            d["result"] = (d["result"] or {}).get("root_cause", "")
        out.append(d)
    return out


@router.delete("/{entity}/{oid}")
def remove(entity: str, oid: int, db: Session = Depends(get_db), admin=Depends(admin_user)):
    if entity not in DELETABLE:
        raise HTTPException(405, "Not deletable")
    o = db.get(ENTITIES[entity], oid)
    if not o:
        raise HTTPException(404, "Not found")
    if entity == "users" and o.id == admin.id:
        raise HTTPException(400, "You cannot delete yourself")
    db.delete(o); db.commit()
    log_activity(db, admin.id, f"admin_deleted_{entity}", str(oid))
    return {"ok": True}


class UserPatch(BaseModel):
    role: str | None = None
    is_active: bool | None = None


@router.patch("/users/{uid}")
def patch_user(uid: int, data: UserPatch, db: Session = Depends(get_db), admin=Depends(admin_user)):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(404, "Not found")
    if u.id == admin.id:
        raise HTTPException(400, "You cannot modify your own role/status")
    if data.role in ("user", "admin"):
        u.role = data.role
    if data.is_active is not None:
        u.is_active = data.is_active
    db.commit()
    return to_dict(u)
