import hmac
from fastapi import APIRouter, BackgroundTasks, Depends, Header, HTTPException
from sqlalchemy.orm import Session
from ..config import settings
from ..database import get_db
from ..models import Repository
from ..security import get_integration
from ..services.pipeline import fetch_and_process, process_failure, save_log, upsert_build

router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])
STATUS = {"SUCCESS": "success", "FAILURE": "failed", "UNSTABLE": "failed", "ABORTED": "cancelled"}


@router.post("/jenkins")
async def jenkins_webhook(data: dict, bg: BackgroundTasks, db: Session = Depends(get_db),
                          x_jenkins_token: str = Header("")):
    """Called by the Jenkinsfile `post {}` block.
    Body: {job, build_number, status, branch, commit, commit_message, author, build_url, log?}"""
    if not settings.jenkins_token or not hmac.compare_digest(x_jenkins_token, settings.jenkins_token):
        raise HTTPException(401, "Invalid or missing X-Jenkins-Token")
    job = str(data.get("job", ""))[:200].strip("/")
    number = data.get("build_number")
    if not job or number is None:
        raise HTTPException(422, "job and build_number are required")
    repo = db.query(Repository).filter_by(full_name=job, provider="jenkins").first()
    if not repo:
        return {"ignored": f"Jenkins job '{job}' is not connected to any project"}
    status = STATUS.get(str(data.get("status", "")).upper(), "running")
    b, _ = upsert_build(db, repo.project_id, repo.id, "jenkins", number, workflow=job,
                        branch=str(data.get("branch", ""))[:200], commit_sha=str(data.get("commit", ""))[:40],
                        commit_message=str(data.get("commit_message", ""))[:500], author=str(data.get("author", ""))[:120],
                        run_url=str(data.get("build_url", ""))[:300], status=status)
    if status == "failed":
        if data.get("log"):  # log sent inline by the pipeline
            save_log(db, b, str(data["log"])[-200000:])
            bg.add_task(process_failure, b.id)
        else:  # otherwise pull the console log from the Jenkins API
            bg.add_task(fetch_and_process, b.id, job, number, get_integration(db, repo.project.owner_id, "jenkins"))
    return {"build_id": b.id, "status": status}
