import re
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field, field_validator
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User, to_dict
from ..security import create_token, current_user, hash_password, verify_password
from ..services.pipeline import log_activity

router = APIRouter(prefix="/api/auth", tags=["auth"])


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)

    @field_validator("password")
    @classmethod
    def strong(cls, v):
        if not (re.search(r"[A-Za-z]", v) and re.search(r"\d", v)):
            raise ValueError("Password must contain letters and digits")
        return v


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=72)


@router.post("/register")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    email = data.email.lower()
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(409, "Email already registered")
    first = db.query(User).count() == 0
    u = User(name=data.name.strip(), email=email, password_hash=hash_password(data.password), role="admin" if first else "user")
    db.add(u); db.commit(); db.refresh(u)
    log_activity(db, u.id, "register", u.email)
    return {"token": create_token(u), "user": to_dict(u)}


@router.post("/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    u = db.query(User).filter_by(email=data.email.lower()).first()
    if not u or not u.is_active or not verify_password(data.password, u.password_hash):
        raise HTTPException(401, "Invalid email or password")
    log_activity(db, u.id, "login", u.email)
    return {"token": create_token(u), "user": to_dict(u)}


@router.get("/me")
def me(user=Depends(current_user)):
    return to_dict(user)
