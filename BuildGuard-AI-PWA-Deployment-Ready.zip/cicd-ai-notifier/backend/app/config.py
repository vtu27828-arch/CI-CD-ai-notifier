from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    secret_key: str = "change-me"
    database_url: str = "sqlite:///./cicd_notifier.db"
    frontend_url: str = "http://localhost:5173"
    demo_mode: bool = True
    token_expire_minutes: int = 720
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-5-5"
    jenkins_token: str = ""
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    slack_webhook_url: str = ""
    teams_webhook_url: str = ""


settings = Settings()
