import base64, hashlib, json, datetime as dt
import bcrypt, jwt
from cryptography.fernet import Fernet
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from . import models
from .config import settings
from .database import get_db

bearer = HTTPBearer(auto_error=False)
_fernet = Fernet(base64.urlsafe_b64encode(hashlib.sha256(settings.secret_key.encode()).digest()))


def hash_password(p: str) -> str:
    return bcrypt.hashpw(p.encode()[:72], bcrypt.gensalt()).decode()


def verify_password(p: str, h: str) -> bool:
    try:
        return bcrypt.checkpw(p.encode()[:72], h.encode())
    except ValueError:
        return False


def create_token(user) -> str:
    exp = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=settings.token_expire_minutes)
    return jwt.encode({"sub": str(user.id), "role": user.role, "exp": exp}, settings.secret_key, algorithm="HS256")


def current_user(cred=Depends(bearer), db: Session = Depends(get_db)):
    if not cred:
        raise HTTPException(401, "Not authenticated")
    try:
        data = jwt.decode(cred.credentials, settings.secret_key, algorithms=["HS256"])
        user = db.get(models.User, int(data["sub"]))
    except (jwt.PyJWTError, ValueError, KeyError):
        raise HTTPException(401, "Invalid or expired token")
    if not user or not user.is_active:
        raise HTTPException(401, "Account disabled")
    return user


def admin_user(user=Depends(current_user)):
    if user.role != "admin":
        raise HTTPException(403, "Admin access required")
    return user


def encrypt_json(d: dict) -> str:
    return _fernet.encrypt(json.dumps(d).encode()).decode()


def decrypt_json(s: str) -> dict:
    try:
        return json.loads(_fernet.decrypt(s.encode()).decode()) if s else {}
    except Exception:
        return {}


def get_integration(db: Session, user_id: int, kind: str) -> dict:
    i = db.query(models.Integration).filter_by(user_id=user_id, kind=kind).first()
    return decrypt_json(i.config_enc) if i else {}
