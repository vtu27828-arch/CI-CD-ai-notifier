import logging
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from . import models
from .config import settings
from .database import Base, engine
from .routes import admin, ai, auth, builds, notifications, projects, webhooks
from .seed import seed
from .services.ai import ai_live

logging.basicConfig(level=logging.INFO)
app = FastAPI(title="CI/CD Build Failure Notification System", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=[settings.frontend_url, "http://localhost:5173"],
                   allow_origin_regex=r"https://[a-zA-Z0-9-]+\.up\.railway\.app", allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
for r in (auth, projects, builds, ai, notifications, webhooks, admin):
    app.include_router(r.router)


@app.on_event("startup")
def startup():
    Base.metadata.create_all(engine)
    if settings.secret_key == "change-me":
        logging.warning("SECRET_KEY is the default value - set a strong one in backend/.env")
    if settings.demo_mode:
        seed()


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    logging.exception("Unhandled error")
    return JSONResponse({"detail": "Internal server error"}, status_code=500)


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/system/status")
def system_status():
    return {"demo_mode": settings.demo_mode, "ai_live": ai_live(), "ai_model": settings.anthropic_model if ai_live() else "demo-rule-engine",
            "smtp": bool(settings.smtp_host), "jenkins_webhook": bool(settings.jenkins_token)}
