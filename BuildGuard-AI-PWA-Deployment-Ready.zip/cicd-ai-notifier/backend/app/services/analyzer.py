"""Rule-based build-log analysis: detects failed stage, category, error lines."""
import re

TS = re.compile(r"^\s*(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?)")
ERR_LINE = re.compile(
    r"(error|fail(ed|ure)?|exception|traceback|fatal|denied|not found|cannot |unable to|##\[error\]|exit code [1-9])", re.I)

STAGES = {
    "dependency_installation": "Dependency Installation", "compilation": "Compilation",
    "testing": "Testing", "deployment": "Deployment", "build": "Build", "configuration": "Configuration",
}
# (stage, category, regex) -- evaluated in priority order
RULES = [
    ("configuration", "Configuration Error",
     r"WorkflowScript: \d+|MultipleCompilationErrorsException|Invalid agent type|Expected a (stage|step)|MissingPropertyException|invalid workflow file|unexpected value|unrecognized named-value|yaml.*(error|invalid)|missing required (env|input)|"
     r"environment variable .*(not set|missing)|secret .*(not found|not set)"),
    ("dependency_installation", "Dependency Error",
     r"ModuleNotFoundError|No module named|Cannot find module|ERESOLVE|npm ERR! (code )?E404|No matching distribution|"
     r"Could not find a version that satisfies|unable to resolve dependency|Could not resolve dependencies"),
    ("compilation", "Compilation Error",
     r"SyntaxError|Compilation failure|IndentationError|error TS\d+|cannot find symbol|compilation (failed|error)|undefined reference|"
     r"error: expected|COMPILATION ERROR"),
    ("testing", "Test Failure",
     r"AssertionError|FAILED .*test|tests? failed|\d+ failed|Test Suites: .*failed"),
    ("deployment", "Deployment Error",
     r"Permission denied \(publickey\)|kubectl|helm |ImagePullBackOff|Error from server|denied: requested access|"
     r"deploy(ment)? (failed|error)|connection refused|Unable to locate credentials"),
    ("build", "Build Error",
     r"failed to solve|make: \*\*\*|BUILD FAILED|npm ERR! (code )?ELIFECYCLE|Module build failed|returned a non-zero code"),
    ("build", "Build Error", r"script returned exit code [1-9]|Finished: FAILURE|Process completed with exit code [1-9]|exit code [1-9]"),
]
_COMPILED = [(s, c, re.compile(rx, re.I)) for s, c, rx in RULES]


def _clean(line: str) -> str:
    return TS.sub("", line).replace("##[error]", "").strip()[:500]


def analyze_log(text: str) -> dict:
    lines = (text or "").splitlines()
    error_lines = []
    for i, l in enumerate(lines, 1):
        if ERR_LINE.search(l):
            m = TS.match(l)
            error_lines.append({"line": i, "text": l.strip()[:400], "timestamp": m.group(1) if m else None})
    for stage, cat, rx in _COMPILED:
        for i, l in enumerate(lines, 1):
            if rx.search(l):
                m = TS.match(l)
                return {"stage": stage, "category": cat, "message": _clean(l), "line": i,
                        "timestamp": m.group(1) if m else None, "error_lines": error_lines[:200]}
    last = error_lines[-1] if error_lines else None
    msg = _clean(last["text"]) if last else (_clean(next((l for l in reversed(lines) if l.strip()), "")) or "Unknown failure")
    return {"stage": "build", "category": "Unknown Error", "message": msg, "line": last["line"] if last else None,
            "timestamp": last["timestamp"] if last else None, "error_lines": error_lines[:200]}


def redact(text: str) -> str:
    """Strip likely secrets before logs are sent to an external AI API."""
    text = re.sub(r"(ghp|gho|ghs|github_pat)_[A-Za-z0-9_]{20,}", "[REDACTED_TOKEN]", text)
    text = re.sub(r"sk-ant-[A-Za-z0-9\-_]{20,}", "[REDACTED_KEY]", text)
    text = re.sub(r"AKIA[0-9A-Z]{16}", "[REDACTED_AWS_KEY]", text)
    return re.sub(r"(?i)(password|passwd|secret|token|api[_-]?key)(\s*[=:]\s*)\S+", r"\1\2[REDACTED]", text)
