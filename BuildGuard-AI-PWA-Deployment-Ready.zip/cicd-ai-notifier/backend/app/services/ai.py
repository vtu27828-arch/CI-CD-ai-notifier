"""Claude-powered debugging layer, with a clearly labelled rule-based DEMO fallback."""
import json, logging, re
from ..config import settings
from .analyzer import redact

log = logging.getLogger("ai")

SYSTEM = """You are a senior DevOps engineer specialising in Jenkins CI/CD. Given a failed build log, respond with ONLY a JSON object (no markdown fences) with keys:
summary (string), root_cause (string), explanation (string: why the build failed), solution (string),
debugging_steps (array of strings), generated_code ({filename, language, code, explanation}),
dependency_fix (null or {filename, content}), config_files (array of {filename, language, content}),
fixed_pipeline (string, a corrected Jenkinsfile using Declarative Pipeline syntax, or empty string if not relevant),
prevention (array of strings), confidence ("high"|"medium"|"low").
Be specific to the actual log. Never invent secrets. Code must be complete and ready for a developer to review."""

CHAT_SYSTEM = """You are an AI CI/CD debugging assistant inside a build-monitoring dashboard. Use the supplied build context
(logs, detected failure, earlier analysis) to answer precisely. Put code in fenced blocks with a language tag.
You never apply changes yourself; developers review and apply them manually. Be concise."""


def ai_live() -> bool:
    return bool(settings.anthropic_api_key)


def _claude(system, messages, max_tokens=3500):
    from anthropic import Anthropic
    c = Anthropic(api_key=settings.anthropic_api_key, timeout=90)
    r = c.messages.create(model=settings.anthropic_model, max_tokens=max_tokens, system=system, messages=messages)
    return "".join(b.text for b in r.content if b.type == "text")


def _json(text):
    return json.loads(text[text.index("{"): text.rindex("}") + 1])


def _excerpt(text, n=7000):
    text = redact(text or "")
    return text if len(text) <= n else text[:1500] + "\n...[truncated]...\n" + text[-(n - 1500):]


def analyze_build(meta: dict, log_text: str, failure: dict, previous=None, feedback="", force_demo=False, variant=0):
    """Returns (result_dict, model_name, is_demo)."""
    if ai_live() and not force_demo:
        prompt = (f"Build: {meta}\nDetected failure: stage={failure['stage']} category={failure['category']} "
                  f"message={failure['message']}\n\nLOG:\n{_excerpt(log_text)}")
        if variant and previous:
            prompt += f"\n\nA previous solution was already given: {previous.get('solution')}. Provide a DIFFERENT alternative approach."
        if feedback:
            prompt += f"\nDeveloper feedback: {feedback[:500]}"
        try:
            return _json(_claude(SYSTEM, [{"role": "user", "content": prompt}])), settings.anthropic_model, False
        except Exception as e:  # network/auth/parse errors -> fall back so the pipeline never breaks
            log.warning("Claude call failed (%s); using demo analysis", e)
    return demo_analysis(failure, variant), "demo-rule-engine", True


def _py_jenkinsfile(extra=""):
    return f"""pipeline {{
  agent any
  stages {{
    stage('Checkout') {{ steps {{ checkout scm }} }}
    stage('Install Dependencies') {{
      steps {{
        sh 'python3 -m venv .venv'
        sh '. .venv/bin/activate && pip install --upgrade pip && pip install -r requirements.txt{extra}'
      }}
    }}
    stage('Test') {{ steps {{ sh '. .venv/bin/activate && pytest' }} }}
  }}
}}
"""


def _node_jenkinsfile():
    return """pipeline {
  agent any
  tools { nodejs 'node-20' }
  stages {
    stage('Checkout') { steps { checkout scm } }
    stage('Install') { steps { sh 'npm ci' } }
    stage('Build') { steps { sh 'npm run build --if-present' } }
    stage('Test') { steps { sh 'npm test' } }
  }
}
"""


def demo_analysis(f: dict, variant=0) -> dict:
    msg, cat = f["message"], f["category"]
    py = re.search(r"No module named '([\w\.\-]+)'", msg)
    node = re.search(r"Cannot find module '([^']+)'", msg)
    alt = bool(variant)
    r = dict(confidence="medium", prevention=[
        "Pin dependency versions and commit lock files.", "Run the same commands locally or in a Docker agent before pushing.",
        "Run the pipeline on pull requests (multibranch) so failures surface early."], config_files=[], dependency_fix=None,
        fixed_pipeline="")
    if py:
        pkg = py.group(1).split(".")[0]
        r.update(summary=f"Python package '{pkg}' is not installed.", root_cause="The required Python package is missing from the build environment.",
                 explanation=f"The code imports '{pkg}', but it is not listed in requirements.txt, so `pip install -r requirements.txt` never installed it on the Jenkins agent.",
                 solution=(f"Add '{pkg}' to requirements.txt." if not alt else f"Install '{pkg}' explicitly in the Jenkinsfile (alternative to editing requirements.txt)."),
                 debugging_steps=["Reproduce locally: python -m venv .venv && pip install -r requirements.txt && pytest",
                                  f"Check that '{pkg}' appears in requirements.txt", "Re-run the Jenkins job after pushing the fix."],
                 generated_code=dict(filename="install.sh", language="bash", code=f"pip install {pkg}",
                                     explanation=f"Installs the missing '{pkg}' package."),
                 dependency_fix=dict(filename="requirements.txt", content=f"flask==3.0.3\n{pkg}\npytest\n"),
                 fixed_pipeline=_py_jenkinsfile(f" {pkg}" if alt else ""), confidence="high")
    elif node:
        pkg = node.group(1)
        r.update(summary=f"Node module '{pkg}' is missing.", root_cause="A required npm package is not declared in package.json.",
                 explanation=f"The code requires '{pkg}', but it is not a dependency, so `npm ci` did not install it.",
                 solution=f"Run `npm install {pkg} --save` and commit package.json and package-lock.json.",
                 debugging_steps=[f"Run npm ls {pkg}", "Delete node_modules and run npm ci locally", "Commit the updated lock file."],
                 generated_code=dict(filename="install.sh", language="bash", code=f"npm install {pkg} --save",
                                     explanation="Adds the dependency to package.json."),
                 dependency_fix=dict(filename="package.json", content='{\n  "dependencies": {\n    "' + pkg + '": "^4.19.2"\n  }\n}'),
                 fixed_pipeline=_node_jenkinsfile(), confidence="high")
    elif cat == "Test Failure":
        r.update(summary="A unit test assertion failed.", root_cause="Application behaviour does not match what the test expects.",
                 explanation=f"The test stage reported: {msg}. Either the code under test has a bug or the expected value is outdated.",
                 solution="Inspect the failing function (e.g. discount/rounding logic), fix the code or update the expectation, then re-run.",
                 debugging_steps=["Run only the failing test: pytest tests/test_cart.py::test_total -x -vv",
                                  "Print intermediate values to find where 90 vs 100 diverges", "Check recent commits touching this code."],
                 generated_code=dict(filename="cart.py", language="python",
                                     code="def total(self):\n    subtotal = sum(i.price * i.qty for i in self.items)\n    return round(subtotal - self.discount, 2)",
                                     explanation="Example fix: apply the discount to the subtotal exactly once."),
                 fixed_pipeline=_py_jenkinsfile())
    elif cat == "Compilation Error":
        r.update(summary="TypeScript/compile error.", root_cause="Code references a symbol or property that does not exist.",
                 explanation=f"The compiler stopped with: {msg}", solution="Fix the property name or extend the type definition.",
                 debugging_steps=["Run npx tsc --noEmit locally", "Open the file/line reported and compare with the type definition."],
                 generated_code=dict(filename="user.ts", language="typescript",
                                     code="export interface User {\n  id: number;\n  fullName: string;\n}",
                                     explanation="Adds the missing 'fullName' property to the User type."), fixed_pipeline=_node_jenkinsfile())
    elif cat == "Configuration Error":
        r.update(summary="The Jenkinsfile has a syntax error.", root_cause="The Declarative Pipeline structure is invalid (e.g. `steps` used outside a `stage`).",
                 explanation=f"Jenkins could not parse the Jenkinsfile: {msg}", solution="Wrap `steps {}` inside a named `stage('...') {}` block and validate the file.",
                 debugging_steps=["Validate with the Declarative Linter (Jenkins > Pipeline Syntax, or jenkins-cli declarative-linter)",
                                  "Compare directives with the Pipeline Syntax reference."],
                 generated_code=dict(filename="Jenkinsfile", language="groovy", code=_py_jenkinsfile(),
                                     explanation="A valid declarative pipeline: every `steps` block sits inside a `stage`."),
                 fixed_pipeline=_py_jenkinsfile(), confidence="high")
    elif cat == "Deployment Error":
        r.update(summary="Deployment authentication failed.", root_cause="The SSH key used by Jenkins is not authorised on the target server.",
                 explanation="The server rejected the connection (publickey), so the deploy stage could not run.",
                 solution="Add the Jenkins public key to ~/.ssh/authorized_keys on the server and store the private key as a Jenkins credential.",
                 debugging_steps=["ssh -i key deploy@host from the Jenkins agent", "Verify the 'deploy-key' credential exists in Jenkins",
                                  "Check server sshd logs."],
                 generated_code=dict(filename="Jenkinsfile", language="groovy", explanation="Uses the SSH Agent plugin with a Jenkins credential.",
                                     code="stage('Deploy') {\n  steps {\n    sshagent(credentials: ['deploy-key']) {\n      sh \"ssh deploy@prod.example.com 'systemctl restart app'\"\n    }\n  }\n}"))
    else:
        r.update(summary="The build step failed.", root_cause="A build command exited with a non-zero status (e.g. missing Dockerfile or wrong build context).",
                 explanation=f"Detected error: {msg}", solution="Make sure the Dockerfile exists at the build context path, or pass `-f path/Dockerfile`.",
                 debugging_steps=["Run the build command locally", "Check `git ls-files | grep Dockerfile`", "Verify the Checkout stage ran (`checkout scm`)."],
                 generated_code=dict(filename="Dockerfile", language="dockerfile", explanation="Minimal Dockerfile to place in the repo root.",
                                     code='FROM python:3.11-slim\nWORKDIR /app\nCOPY requirements.txt .\nRUN pip install --no-cache-dir -r requirements.txt\nCOPY . .\nCMD ["python", "main.py"]'))
    r["demo_notice"] = "Generated by the built-in DEMO rule engine. Add ANTHROPIC_API_KEY for live Claude analysis."
    return r


def chat(message: str, history: list, ctx: dict | None):
    """ctx: {meta, log, failure, analysis}. Returns (reply, demo)."""
    context = ""
    if ctx:
        context = (f"BUILD CONTEXT\nMeta: {ctx['meta']}\nFailure: {ctx['failure']}\nPrior analysis: "
                   f"{json.dumps(ctx.get('analysis') or {})[:3000]}\nLOG:\n{_excerpt(ctx['log'], 5000)}\n\n")
    if ai_live():
        msgs = [{"role": h["role"], "content": str(h["content"])[:4000]} for h in history[-10:] if h.get("role") in ("user", "assistant")]
        msgs.append({"role": "user", "content": context + message})
        try:
            return _claude(CHAT_SYSTEM, msgs, 1800), False
        except Exception as e:
            log.warning("Claude chat failed: %s", e)
    return _demo_chat(message, ctx), True


def _demo_chat(q, ctx):
    tag = "\n\n_(Demo mode reply - set ANTHROPIC_API_KEY for live Claude answers.)_"
    if not ctx:
        return "Select a build above so I can use its Jenkins console log as context. I can explain errors, generate fixes, and write Jenkinsfiles." + tag
    a = ctx.get("analysis") or demo_analysis(ctx["failure"])
    ql = q.lower()
    code = a.get("generated_code") or {}
    if re.search(r"another|different|alternative", ql):
        return f"**Alternative approach:** {demo_analysis(ctx['failure'], 1)['solution']}" + tag
    if re.search(r"jenkinsfile|pipeline|groovy|yaml", ql) and a.get("fixed_pipeline"):
        return f"Here is a corrected Jenkinsfile:\n```groovy\n{a['fixed_pipeline']}```" + tag
    if re.search(r"docker", ql):
        return "Docker checklist: confirm the Dockerfile path/context, check base image tags, and make sure the Jenkins agent can reach the Docker daemon.\n```dockerfile\nFROM python:3.11-slim\nWORKDIR /app\nCOPY . .\n```" + tag
    if re.search(r"code|fix|correct|generate|dependency", ql) and code:
        return f"**Solution:** {a['solution']}\n```{code.get('language', '')}\n{code.get('code', '')}\n```\n{code.get('explanation', '')}" + tag
    return f"**Root cause:** {a['root_cause']}\n\n{a['explanation']}\n\n**Fix:** {a['solution']}" + tag
