import smtplib
from email.message import EmailMessage
import httpx
from sqlalchemy.orm import Session
from ..config import settings
from ..models import Notification
from ..security import get_integration

CHANNELS = ("email", "slack", "teams")


def compose(build, failure, analysis: dict) -> dict:
    link = f"{settings.frontend_url}/logs/{build.id}"
    repo = build.repository.full_name if build.repository else "-"
    fields = [("Project", build.project.name), ("Repository", repo), ("Build ID", f"#{build.id}"),
              ("Failed stage", failure.stage), ("Error", failure.error_message[:300]),
              ("Failure time", failure.detected_at.strftime("%Y-%m-%d %H:%M:%S UTC")),
              ("AI solution", (analysis.get("solution") or "n/a")[:400]), ("Dashboard", link)]
    return {"title": f"Build #{build.id} FAILED - {build.project.name}", "fields": fields, "link": link}


def _text(m):
    return m["title"] + "\n" + "\n".join(f"{k}: {v}" for k, v in m["fields"])


def _email(to, m):
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = m["title"], settings.smtp_from or settings.smtp_user, to
    msg.set_content(_text(m))
    rows = "".join(f"<tr><td><b>{k}</b></td><td>{v}</td></tr>" for k, v in m["fields"])
    msg.add_alternative(f"<h3>{m['title']}</h3><table cellpadding=6>{rows}</table>", subtype="html")
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as s:
        s.starttls()
        if settings.smtp_user:
            s.login(settings.smtp_user, settings.smtp_password)
        s.send_message(msg)


def _slack(url, m):
    httpx.post(url, json={"text": ":rotating_light: *" + m["title"] + "*\n" + "\n".join(f"*{k}:* {v}" for k, v in m["fields"])},
               timeout=15).raise_for_status()


def _teams(url, m):
    card = {"type": "AdaptiveCard", "version": "1.4", "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "body": [{"type": "TextBlock", "text": m["title"], "weight": "Bolder", "size": "Medium", "color": "Attention"},
                     {"type": "FactSet", "facts": [{"title": k, "value": str(v)} for k, v in m["fields"]]}],
            "actions": [{"type": "Action.OpenUrl", "title": "Open dashboard", "url": m["link"]}]}
    httpx.post(url, json={"type": "message", "attachments": [{"contentType": "application/vnd.microsoft.card.adaptive",
                                                              "content": card}]}, timeout=15).raise_for_status()


def send_all(db: Session, build, failure, analysis: dict, only=None):
    owner = build.project.owner
    m = compose(build, failure, analysis)
    cfg = {
        "email": (get_integration(db, owner.id, "email").get("to") or owner.email) if settings.smtp_host else None,
        "slack": get_integration(db, owner.id, "slack").get("webhook_url") or settings.slack_webhook_url or None,
        "teams": get_integration(db, owner.id, "teams").get("webhook_url") or settings.teams_webhook_url or None,
    }
    results = []
    for ch in CHANNELS:
        if only and ch not in only:
            continue
        target, status, detail = cfg[ch], "sent", ""
        if not target:
            status, detail = ("simulated", "Demo mode: channel not configured, message not sent") if settings.demo_mode else (
                "skipped", "Channel not configured")
        else:
            try:
                {"email": _email, "slack": _slack, "teams": _teams}[ch](target, m)
                detail = "Delivered"
            except Exception as e:
                status, detail = "failed", str(e)[:300]
        db.add(Notification(build_id=build.id, channel=ch, status=status, detail=detail))
        results.append({"channel": ch, "status": status, "detail": detail})
    db.commit()
    return results
