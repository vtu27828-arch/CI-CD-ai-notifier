"""Jenkins REST API client (jobs, builds, console logs)."""
import datetime as dt
from urllib.parse import urlparse
import httpx


def _base(url: str) -> str:
    u = urlparse(url)
    if u.scheme not in ("http", "https") or not u.netloc:
        raise ValueError("Jenkins URL must start with http:// or https://")
    return url.rstrip("/")


def job_path(job: str) -> str:
    """'folder/my job' -> '/job/folder/job/my%20job'"""
    from urllib.parse import quote
    return "".join(f"/job/{quote(p)}" for p in job.strip("/").split("/") if p)


def _get(cfg: dict, path: str, **params):
    r = httpx.get(_base(cfg["url"]) + path, params=params, auth=(cfg["user"], cfg["token"]), timeout=25)
    r.raise_for_status()
    return r


def list_jobs(cfg: dict):
    tree = "jobs[name,fullName,url,color,jobs[name,fullName,url,color,jobs[name,fullName,url,color]]]"
    out = []

    def walk(items):
        for j in items or []:
            if "jobs" in j and j["jobs"]:
                walk(j["jobs"])
            elif j.get("color") is not None or "jobs" not in j:
                out.append({"full_name": j.get("fullName") or j["name"], "url": j.get("url", "")})
    walk(_get(cfg, "/api/json", tree=tree).json().get("jobs"))
    return out


def list_builds(cfg: dict, job: str, n=20):
    tree = (f"builds[number,result,building,timestamp,duration,url,"
            f"actions[lastBuiltRevision[SHA1,branch[name]]],changeSet[items[msg,author[fullName]]]]{{0,{n}}}")
    return _get(cfg, job_path(job) + "/api/json", tree=tree).json().get("builds", [])


def console_log(cfg: dict, job: str, number) -> str:
    return _get(cfg, f"{job_path(job)}/{number}/consoleText").text[-200000:]


def build_to_fields(job: str, b: dict) -> dict:
    sha, branch = "", ""
    for a in b.get("actions", []):
        rev = (a or {}).get("lastBuiltRevision")
        if rev:
            sha = rev.get("SHA1", "")
            branch = ((rev.get("branch") or [{}])[0].get("name") or "").replace("refs/remotes/origin/", "")
    items = (b.get("changeSet") or {}).get("items") or []
    status = "running" if b.get("building") else {"SUCCESS": "success", "FAILURE": "failed", "UNSTABLE": "failed",
                                                   "ABORTED": "cancelled"}.get(b.get("result") or "", "running")
    started = dt.datetime.utcfromtimestamp(b["timestamp"] / 1000) if b.get("timestamp") else None
    return dict(workflow=job, branch=branch, commit_sha=sha[:40], status=status, run_url=b.get("url", ""),
                commit_message=(items[0].get("msg") if items else "")[:500] if items else "",
                author=((items[0].get("author") or {}).get("fullName", "")) if items else "", started_at=started)
