"""Failure pipeline: detect -> store -> AI analysis -> notify."""
import logging
from ..database import SessionLocal
from ..models import AIAnalysis, Activity, Build, BuildLog, Failure, now
from . import ai, jenkins, notify
from .analyzer import analyze_log

log = logging.getLogger("pipeline")


def log_activity(db, user_id, action, detail=""):
    db.add(Activity(user_id=user_id, action=action, detail=detail[:500]))
    db.commit()


def upsert_build(db, project_id, repo_id, source, run_id, **fields):
    b = None
    if run_id:
        b = db.query(Build).filter_by(project_id=project_id, source=source, run_id=str(run_id)).first()
    created = b is None
    if created:
        b = Build(project_id=project_id, repository_id=repo_id, source=source, run_id=str(run_id) if run_id else None)
        db.add(b)
    for k, v in fields.items():
        if v is not None:
            setattr(b, k, v)
    if b.status in ("success", "failed", "cancelled") and not b.finished_at:
        b.finished_at = now()
    db.commit()
    db.refresh(b)
    return b, created


def save_log(db, build, text):
    if build.log:
        build.log.content = text
    else:
        db.add(BuildLog(build_id=build.id, content=text))
    db.commit()


def process_failure(build_id: int, force_demo=False, notify_users=True):
    db = SessionLocal()
    try:
        b = db.get(Build, build_id)
        if not b:
            return
        text = b.log.content if b.log else ""
        res = analyze_log(text)
        f = b.failure or Failure(build_id=b.id)
        f.stage, f.category, f.error_message, f.error_lines = res["stage"], res["category"], res["message"], res["error_lines"]
        f.detected_at = now()
        db.add(f)
        b.status, b.failed_stage, b.error_message = "failed", res["stage"], res["message"]
        db.commit()
        meta = {"project": b.project.name, "repo": b.repository.full_name if b.repository else None, "branch": b.branch,
                "commit": b.commit_sha, "workflow": b.workflow}
        result, model, demo = ai.analyze_build(meta, text, res, force_demo=force_demo)
        db.add(AIAnalysis(build_id=b.id, result=result, model=model, demo=demo, version=len(b.analyses) + 1))
        db.commit()
        if notify_users:
            db.refresh(b)
            notify.send_all(db, b, f, result)
        log_activity(db, b.project.owner_id, "build_failure_processed", f"Build #{b.id}: {res['category']}")
    except Exception:
        log.exception("process_failure failed for build %s", build_id)
        db.rollback()
    finally:
        db.close()


def fetch_and_process(build_id: int, job: str, number, cfg: dict | None):
    """Used by Jenkins webhook/sync: pull the console log from Jenkins, then run the pipeline."""
    db = SessionLocal()
    try:
        b = db.get(Build, build_id)
        text = None
        if cfg and cfg.get("url"):
            try:
                text = jenkins.console_log(cfg, job, number)
            except Exception as e:
                log.warning("console fetch failed: %s", e)
        if not text:
            text = (f"Jenkins job '{job}' #{number} failed on branch {b.branch}.\n"
                    "ERROR: Console log could not be retrieved. Configure Jenkins URL/user/token in Settings, "
                    "or send the log in the webhook payload.")
        save_log(db, b, text)
    finally:
        db.close()
    process_failure(build_id)
