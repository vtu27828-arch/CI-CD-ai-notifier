"""Sample Jenkins console logs used by Demo Mode (seed data + 'Simulate failure')."""
import datetime as dt

HDR = ["Started by user admin", "Running on built-in node in /var/jenkins_home/workspace/payments-api-pipeline",
       "[Pipeline] stage", "[Pipeline] { (Checkout)", "Cloning repository https://git.example.com/payments-api.git"]
FAIL = ["[Pipeline] }", "[Pipeline] // stage", "Finished: FAILURE"]

SCENARIOS = {
    "python_module": HDR + ["[Pipeline] { (Install Dependencies)", "+ pip install -r requirements.txt",
        "Successfully installed flask-3.0.3", "[Pipeline] { (Test)", "+ pytest", "Traceback (most recent call last):",
        '  File "app/client.py", line 3, in <module>', "    import requests",
        "ModuleNotFoundError: No module named 'requests'", "ERROR: script returned exit code 1"] + FAIL,
    "npm_module": HDR + ["[Pipeline] { (Install)", "+ npm ci", "added 312 packages in 9s", "[Pipeline] { (Test)", "+ npm test",
        "node:internal/modules/cjs/loader:1080", "Error: Cannot find module 'express'", "Require stack:",
        "- /var/jenkins_home/workspace/api/server.js", "ERROR: script returned exit code 1"] + FAIL,
    "test_fail": HDR + ["[Pipeline] { (Test)", "+ pytest -q", "collected 13 items", "tests/test_cart.py .F",
        "=================== FAILURES ===================", ">       assert cart.total() == 100",
        "E       AssertionError: assert 90 == 100",
        "FAILED tests/test_cart.py::test_total - AssertionError: assert 90 == 100", "1 failed, 12 passed in 2.31s",
        "ERROR: script returned exit code 1"] + FAIL,
    "docker_build": HDR + ["[Pipeline] { (Docker Build)", "+ docker build -t payments-api .",
        "#1 [internal] load build definition from Dockerfile",
        "ERROR: failed to solve: failed to read dockerfile: open Dockerfile: no such file or directory",
        "ERROR: script returned exit code 1"] + FAIL,
    "jenkinsfile_syntax": ["Started by user admin", "org.codehaus.groovy.control.MultipleCompilationErrorsException: startup failed:",
        "WorkflowScript: 6: Expected a stage @ line 6, column 5.", "       steps {", "       ^",
        "1 error", "Finished: FAILURE"],
    "deploy": HDR + ["[Pipeline] { (Deploy)", "+ ssh deploy@prod.example.com 'systemctl restart app'",
        "Warning: Permanently added 'prod.example.com' to the list of known hosts.",
        "deploy@prod.example.com: Permission denied (publickey).", "ERROR: script returned exit code 255"] + FAIL,
    "typescript": HDR + ["[Pipeline] { (Build)", "+ npm run build", "> web@0.1.0 build", "> tsc && vite build",
        "src/components/UserCard.tsx(14,22): error TS2339: Property 'fullName' does not exist on type 'User'.",
        "Found 1 error.", "ERROR: script returned exit code 2"] + FAIL,
}
SUCCESS_LOG = HDR + ["[Pipeline] { (Test)", "+ pytest -q", "13 passed in 2.04s", "[Pipeline] }", "Finished: SUCCESS"]


def make_log(lines, start=None):
    t = start or dt.datetime.utcnow()
    return "\n".join(f"{(t + dt.timedelta(seconds=i * 2)).strftime('%Y-%m-%dT%H:%M:%SZ')} {l}" for i, l in enumerate(lines))
