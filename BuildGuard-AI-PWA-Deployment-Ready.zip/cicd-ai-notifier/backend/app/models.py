import datetime as dt
from sqlalchemy import JSON, Boolean, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from .database import Base


def now():
    return dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(80), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), default="user")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)
    projects = relationship("Project", back_populates="owner", cascade="all, delete-orphan")
    integrations = relationship("Integration", cascade="all, delete-orphan")


class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(120), nullable=False)
    description = Column(String(500), default="")
    created_at = Column(DateTime, default=now)
    owner = relationship("User", back_populates="projects")
    repositories = relationship("Repository", back_populates="project", cascade="all, delete-orphan")
    builds = relationship("Build", back_populates="project", cascade="all, delete-orphan")


class Repository(Base):
    __tablename__ = "repositories"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    provider = Column(String(20), default="jenkins")
    full_name = Column(String(200), nullable=False, index=True)
    default_branch = Column(String(100), default="main")
    html_url = Column(String(300), default="")
    created_at = Column(DateTime, default=now)
    project = relationship("Project", back_populates="repositories")
    builds = relationship("Build", back_populates="repository")


class Build(Base):
    __tablename__ = "builds"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    repository_id = Column(Integer, ForeignKey("repositories.id"), nullable=True)
    source = Column(String(20), default="jenkins")  # jenkins | upload | demo
    run_id = Column(String(60), index=True)
    workflow = Column(String(200), default="")
    branch = Column(String(200), default="")
    commit_sha = Column(String(60), default="")
    commit_message = Column(String(500), default="")
    author = Column(String(120), default="")
    status = Column(String(20), default="running")  # running | success | failed | cancelled
    failed_stage = Column(String(40))
    error_message = Column(Text)
    run_url = Column(String(300), default="")
    started_at = Column(DateTime, default=now)
    finished_at = Column(DateTime)
    created_at = Column(DateTime, default=now)
    project = relationship("Project", back_populates="builds")
    repository = relationship("Repository", back_populates="builds")
    log = relationship("BuildLog", uselist=False, cascade="all, delete-orphan")
    failure = relationship("Failure", uselist=False, cascade="all, delete-orphan")
    analyses = relationship("AIAnalysis", cascade="all, delete-orphan", order_by="AIAnalysis.id")
    notifications = relationship("Notification", cascade="all, delete-orphan", order_by="Notification.id")


class BuildLog(Base):
    __tablename__ = "build_logs"
    id = Column(Integer, primary_key=True)
    build_id = Column(Integer, ForeignKey("builds.id"), unique=True, nullable=False)
    content = Column(Text, default="")


class Failure(Base):
    __tablename__ = "failures"
    id = Column(Integer, primary_key=True)
    build_id = Column(Integer, ForeignKey("builds.id"), unique=True, nullable=False)
    stage = Column(String(40))
    category = Column(String(60))
    error_message = Column(Text)
    error_lines = Column(JSON, default=list)
    detected_at = Column(DateTime, default=now)


class AIAnalysis(Base):
    __tablename__ = "ai_analyses"
    id = Column(Integer, primary_key=True)
    build_id = Column(Integer, ForeignKey("builds.id"), nullable=False)
    result = Column(JSON, default=dict)
    model = Column(String(80), default="")
    demo = Column(Boolean, default=False)
    version = Column(Integer, default=1)
    created_at = Column(DateTime, default=now)


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    build_id = Column(Integer, ForeignKey("builds.id"), nullable=False)
    channel = Column(String(20))  # email | slack | teams
    status = Column(String(20))  # sent | failed | skipped | simulated
    detail = Column(String(500), default="")
    created_at = Column(DateTime, default=now)


class Integration(Base):
    __tablename__ = "integrations"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    kind = Column(String(20), nullable=False)  # jenkins | slack | teams | email
    config_enc = Column(Text, default="")  # Fernet-encrypted JSON
    created_at = Column(DateTime, default=now)


class Activity(Base):
    __tablename__ = "activity"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, nullable=True)
    action = Column(String(60))
    detail = Column(String(500), default="")
    created_at = Column(DateTime, default=now)


def to_dict(o, skip=("password_hash", "config_enc")):
    d = {}
    for c in o.__table__.columns:
        if c.name in skip:
            continue
        v = getattr(o, c.name)
        d[c.name] = v.isoformat() + "Z" if isinstance(v, dt.datetime) else v
    return d
