"""Demo data: two accounts, one project, ~20 builds over the last week (processed through the real pipeline)."""
import datetime as dt, random, secrets
from .database import SessionLocal
from .models import Project, Repository, User
from .security import hash_password
from .services import samples
from .services.pipeline import process_failure, save_log, upsert_build


def seed():
    db = SessionLocal()
    try:
        if db.query(User).count():
            return
        admin = User(name="Demo Admin", email="admin@demo.dev", password_hash=hash_password("Admin@123"), role="admin")
        dev = User(name="Demo Developer", email="dev@demo.dev", password_hash=hash_password("Dev@12345"))
        db.add_all([admin, dev]); db.commit()
        p = Project(owner_id=admin.id, name="Payments Service", description="Demo project with sample CI/CD data")
        db.add(p); db.commit()
        r = Repository(project_id=p.id, provider="jenkins", full_name="payments-api-pipeline", html_url="http://localhost:8080/job/payments-api-pipeline/")
        db.add(r); db.commit()
        random.seed(7)
        failing = []
        for i in range(22):
            t = dt.datetime.utcnow() - dt.timedelta(days=random.randint(0, 6), hours=random.randint(0, 20))
            fail = random.random() < 0.4
            b, _ = upsert_build(db, p.id, r.id, "demo", f"seed{i}", workflow="CI", branch=random.choice(["main", "develop", "feature/login"]),
                                commit_sha=secrets.token_hex(20), commit_message=random.choice(["Fix cart total", "Add refund API", "Bump deps", "Update CI"]),
                                author="Demo Admin", status="failed" if fail else "success", started_at=t, created_at=t)
            b.finished_at = t + dt.timedelta(seconds=random.randint(40, 300)); db.commit()
            if fail:
                key = random.choice(list(samples.SCENARIOS))
                save_log(db, b, samples.make_log(samples.SCENARIOS[key], t)); failing.append(b.id)
            else:
                save_log(db, b, samples.make_log(samples.SUCCESS_LOG, t))
        for bid in failing:
            process_failure(bid, force_demo=True)
    finally:
        db.close()
